/* ==========================================================================
   OrbitGuard · Mission Control 3D Lab
   - Three.js scene in the ECI frame (Earth spins with GMST)
   - Real catalogue (CelesTrak GP API via OrbitEngine) rendered as a point cloud
   - Guided 6-step walkthrough + free explore mode
   - Conjunction list, range-vs-time chart, mitigation planning & SGP4 re-verification
   ========================================================================== */
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createEarth, createStars, eciToScene, sunDirection, glowTexture, pointsMaterial, RE } from './globe.js';

const E = window.OrbitEngine;
const $ = (id) => document.getElementById(id);
const canvas = $('lab-canvas');

if (canvas && E && window.satellite) main();
else if (canvas) console.error('OrbitGuard Lab: OrbitEngine / satellite.js not available');

function main() {
  /* ------------------------------------------------------------ constants */
  const GROUP_ORDER = ['stations', 'visual', 'weather', 'fengyun-1c-debris', 'cosmos-2251-debris', 'iridium-33-debris'];
  const DEBRIS = new Set(['fengyun-1c-debris', 'cosmos-2251-debris', 'iridium-33-debris']);
  const COL = {
    debris: [1, 0.54, 0.24], active: [0.22, 0.88, 1], synthetic: [1, 0.32, 0.62],
    threat: [1, 0.3, 0.37], flagged: [1, 0.69, 0.13]
  };

  /* ---------------------------------------------------------------- helpers */
  const pad = (n) => String(n).padStart(2, '0');
  const hms = (ms) => { const d = new Date(ms); return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`; };
  const ymd = (ms) => new Date(ms).toISOString().slice(0, 10);
  const dur = (ms) => { const s = Math.round(Math.abs(ms) / 1000); return `${ms < 0 ? '−' : '+'}${pad(Math.floor(s / 3600))}:${pad(Math.floor(s % 3600 / 60))}:${pad(s % 60)}`; };
  const km = (d) => d == null || !isFinite(d) ? '—' : d < 1 ? (d * 1000).toFixed(0) + ' m' : d < 100 ? d.toFixed(2) + ' km' : Math.round(d).toLocaleString() + ' km';
  const kmS = (d) => (d >= 0 ? '+' : '') + d.toFixed(3) + ' km';
  const pcFmt = (p) => p < 1e-12 ? '< 1e-12' : p.toExponential(1);
  const dvFmt = (dv) => dv < 1 ? (dv * 100).toFixed(2) + ' cm/s' : dv.toFixed(3) + ' m/s';
  const fuelFmt = (kg) => kg < 1 ? (kg * 1000).toFixed(1) + ' g' : kg.toFixed(2) + ' kg';
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const ease = (k) => k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
  const groupShort = (g) => g === 'synthetic' ? 'Synthetic test' : (E.GROUPS[g] ? E.GROUPS[g].short : g);
  const massOf = (o) => /ISS/.test(o.name) ? 420000 : /CSS|TIANHE/.test(o.name) ? 66000 : /HST/.test(o.name) ? 11100 : 1500;

  /* ------------------------------------------------------------------ state */
  const S = {
    base: [], objects: [], catalogs: [], target: null, insp: null,
    simMs: Date.now(), playing: true, speed: 60, scrubbing: false,
    winStart: Date.now(), winLen: 6 * 3600e3,
    coarse: null, result: null, sel: null, plan: null, post: null, verified: null,
    step: 0, mode: 'guided', busy: false, progress: 0, ready: false, booting: false
  };
  const vis = {};

  /* ------------------------------------------------------------------ DOM */
  const dom = {
    boot: $('boot'), bootBtn: $('bootBtn'), labRoot: $('labRoot'), viewport: $('viewport'),
    steps: $('steps'), exKicker: $('exKicker'), exTitle: $('exTitle'), exBody: $('exBody'), ex3d: $('ex3d'), exFormula: $('exFormula'),
    prev: $('prevStep'), next: $('nextStep'), consoleBody: $('consoleBody'), srcBadge: $('srcBadge'),
    insp: $('inspector'), inspName: $('inspName'), inspGrid: $('inspGrid'), inspClose: $('inspClose'), inspTarget: $('inspTarget'),
    hudCenter: $('hudCenter'), play: $('playBtn'), simTime: $('simTime'), simDate: $('simDate'), scrub: $('scrub'),
    speed: $('speed'), now: $('nowBtn'), cam: $('camBtn'),
    targetSel: $('targetSel'), winIn: $('winIn'), winOut: $('winOut'), thrIn: $('thrIn'), thrOut: $('thrOut'),
    stepIn: $('stepIn'), safeIn: $('safeIn'), injectIn: $('injectIn'), catalogs: $('catalogs'), runBtn: $('runBtn'),
    conjList: $('conjList'), conjMeta: $('conjMeta'), chartMeta: $('chartMeta'), chartCanvas: $('rangeChart'), mitig: $('mitig'),
    labels: $('labels')
  };

  /* --------------------------------------------------------------- console */
  function log(text, cls = '') {
    const d = document.createElement('div');
    if (cls) d.className = cls;
    d.textContent = text;
    dom.consoleBody.appendChild(d);
    while (dom.consoleBody.children.length > 250) dom.consoleBody.firstChild.remove();
    dom.consoleBody.scrollTop = dom.consoleBody.scrollHeight;
  }
  log('OrbitGuard mission console v1.0', 'c-dim');
  log('Press “Initialise & fetch data” to connect to CelesTrak.', 'c-dim');

  /* ----------------------------------------------------------------- scene */
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setClearColor(0x000000, 1);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, 1, 0.002, 400);
  camera.position.set(0, 1.5, 4.4);
  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true; controls.dampingFactor = 0.08;
  controls.minDistance = 0.06; controls.maxDistance = 14;
  controls.rotateSpeed = 0.6; controls.zoomSpeed = 0.8; controls.autoRotateSpeed = 0.35;
  controls.enablePan = false;

  const earth = createEarth({ segments: 96 });
  scene.add(earth.root);
  scene.add(createStars(4000));

  // ---- catalogue point cloud
  const pmat = pointsMaterial();
  pmat.uniforms.uScale.value = 1.5;
  let pgeo = new THREE.BufferGeometry();
  const points = new THREE.Points(pgeo, pmat);
  points.frustumCulled = false;
  scene.add(points);
  let cap = 0, posArr, colArr, sizeArr, alphaArr, P, V, T, OK;
  function allocPoints(n) {
    cap = n;
    posArr = new Float32Array(n * 3); colArr = new Float32Array(n * 3);
    sizeArr = new Float32Array(n); alphaArr = new Float32Array(n);
    P = new Float64Array(n * 3); V = new Float64Array(n * 3); T = new Float64Array(n); OK = new Uint8Array(n);
    pgeo.dispose();
    pgeo = new THREE.BufferGeometry();
    const attr = (arr, k) => new THREE.BufferAttribute(arr, k).setUsage(THREE.DynamicDrawUsage);
    pgeo.setAttribute('position', attr(posArr, 3));
    pgeo.setAttribute('aColor', attr(colArr, 3));
    pgeo.setAttribute('aSize', attr(sizeArr, 1));
    pgeo.setAttribute('aAlpha', attr(alphaArr, 1));
    points.geometry = pgeo;
  }
  allocPoints(16);
  pgeo.setDrawRange(0, 0);

  // ---- markers
  const glowW = glowTexture('rgba(255,255,255,1)');
  const glowR = glowTexture('rgba(255,77,94,1)');
  const glowG = glowTexture('rgba(61,255,154,1)');
  const glowC = glowTexture('rgba(56,225,255,1)');
  function marker(tex, k) {
    const m = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
    m.userData.k = k; m.visible = false; scene.add(m); return m;
  }
  const mTarget = marker(glowW, 0.045), mThreat = marker(glowR, 0.045), mPost = marker(glowG, 0.04),
    mBurn = marker(glowG, 0.03), mInsp = marker(glowC, 0.04);

  // ---- lines
  function makeLine(color, opacity, n) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
    const l = new THREE.Line(g, new THREE.LineBasicMaterial({ color, transparent: true, opacity, depthWrite: false }));
    l.frustumCulled = false; l.visible = false; scene.add(l); return l;
  }
  const oTarget = makeLine(0xffffff, 0.55, 241), oThreat = makeLine(0xff4d5e, 0.65, 241), oPost = makeLine(0x3dff9a, 0.85, 241);
  const lEnc = makeLine(0xff4d5e, 0.95, 2), lRad = makeLine(0x38e1ff, 0.7, 2);

  function fillOrbit(line, rec, startMs, spanMs) {
    const a = line.geometry.attributes.position, n = a.count;
    let last = null;
    for (let i = 0; i < n; i++) {
      const p = E.posAt(rec, startMs + spanMs * i / (n - 1));
      if (p) last = p;
      if (last) a.setXYZ(i, last.x / RE, last.z / RE, -last.y / RE);
    }
    a.needsUpdate = true;
    line.geometry.computeBoundingSphere();
    line.userData.rec = rec; line.userData.ms = S.simMs;
  }
  function setLine2(line, a, b) {
    const p = line.geometry.attributes.position;
    p.setXYZ(0, a.x, a.y, a.z); p.setXYZ(1, b.x, b.y, b.z); p.needsUpdate = true;
  }

  // ---- filter shells
  function shell(color) {
    const g = new THREE.Group();
    g.add(new THREE.Mesh(new THREE.SphereGeometry(1, 64, 48), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.05, side: THREE.DoubleSide, depthWrite: false })));
    g.add(new THREE.Mesh(new THREE.SphereGeometry(1, 36, 18), new THREE.MeshBasicMaterial({ color, wireframe: true, transparent: true, opacity: 0.09, depthWrite: false })));
    g.visible = false; scene.add(g); return g;
  }
  const shLo = shell(0x38e1ff), shHi = shell(0xa86bff);

  // ---- arrows
  function arrow(color) {
    const a = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), new THREE.Vector3(), 0.1, color, 0.025, 0.012);
    a.visible = false; scene.add(a); return a;
  }
  const arV = arrow(0x38e1ff), arR = arrow(0xff5c8a), arI = arrow(0xffb020), arC = arrow(0xa86bff), arM = arrow(0xffffff);

  // ---- dynamic scene vectors
  const tPos = new THREE.Vector3(), thPos = new THREE.Vector3(), postPos = new THREE.Vector3(), burnPos = new THREE.Vector3(), inspPos = new THREE.Vector3();
  const tips = { R: new THREE.Vector3(), I: new THREE.Vector3(), C: new THREE.Vector3() };
  const shellLbl = { lo: new THREE.Vector3(), hi: new THREE.Vector3() };
  const live = { tpv: null, range: null, threatOk: false, postOk: false };
  const sunV = new THREE.Vector3();
  const tmpV = new THREE.Vector3();

  /* ---------------------------------------------------------------- labels */
  let labels = [];
  function setLabels(list) {
    dom.labels.innerHTML = '';
    labels = list.map((l) => {
      const el = document.createElement('div');
      el.className = 'lbl ' + (l.cls || '');
      dom.labels.appendChild(el);
      return Object.assign({}, l, { el });
    });
  }
  function occluded(p) {
    const C = camera.position;
    tmpV.copy(p).sub(C); const L = tmpV.length(); tmpV.divideScalar(L);
    const b = C.dot(tmpV), c = C.lengthSq() - 1, disc = b * b - c;
    if (disc <= 0) return false;
    const t = -b - Math.sqrt(disc);
    return t > 0 && t < L - 1e-3;
  }
  const projV = new THREE.Vector3();
  let labelTick = 0;
  function updateLabels() {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    const refreshText = (labelTick++ % 8) === 0;
    for (const l of labels) {
      const p = l.pos();
      if (!p || (l.when && !l.when())) { l.el.style.display = 'none'; continue; }
      projV.copy(p).project(camera);
      if (projV.z > 1 || occluded(p)) { l.el.style.display = 'none'; continue; }
      l.el.style.display = '';
      l.el.style.left = ((projV.x + 1) / 2 * w).toFixed(1) + 'px';
      l.el.style.top = ((1 - projV.y) / 2 * h).toFixed(1) + 'px';
      if (refreshText || !l.el.textContent) l.el.textContent = typeof l.text === 'function' ? l.text() : l.text;
    }
  }

  /* ----------------------------------------------------------- propagation */
  let rr = 0, forceFull = true;
  function propagate(i, ms) {
    const pv = E.posVelAt(S.objects[i], ms);
    if (!pv) { OK[i] = 0; return; }
    const p = pv.position, v = pv.velocity, j = i * 3;
    P[j] = p.x; P[j + 1] = p.y; P[j + 2] = p.z;
    V[j] = v.x; V[j + 1] = v.y; V[j + 2] = v.z;
    T[i] = ms; OK[i] = 1;
  }
  function updatePoints() {
    const n = S.objects.length;
    if (!n) return;
    if (forceFull) { for (let i = 0; i < n; i++) propagate(i, S.simMs); forceFull = false; }
    else {
      const budget = Math.min(n, 700);
      for (let k = 0; k < budget; k++) { if (rr >= n) rr = 0; propagate(rr, S.simMs); rr++; }
    }
    for (let i = 0; i < n; i++) {
      const j = i * 3;
      if (!OK[i]) { posArr[j] = posArr[j + 1] = posArr[j + 2] = 0; continue; }
      const dt = (S.simMs - T[i]) / 1000;
      const x = P[j] + V[j] * dt, y = P[j + 1] + V[j + 1] * dt, z = P[j + 2] + V[j + 2] * dt;
      posArr[j] = x / RE; posArr[j + 1] = z / RE; posArr[j + 2] = -y / RE;
    }
    pgeo.attributes.position.needsUpdate = true;
  }
  function jumpTo(ms) { S.simMs = ms; forceFull = true; }

  function paint() {
    const n = S.objects.length;
    if (!n) return;
    const dim = vis.dim && S.coarse;
    const rej = dim ? new Set(S.coarse.rejected) : null;
    const flagged = new Set();
    if (S.result) S.result.conjunctions.forEach((c) => { if (c.miss <= S.result.thresholdKm) flagged.add(c.obj); });
    for (let i = 0; i < n; i++) {
      const o = S.objects[i];
      let c = COL[o.kind] || COL.active, s = o.kind === 'debris' ? 1 : 1.7, a = o.kind === 'debris' ? 0.85 : 1;
      if (o.kind === 'synthetic') s = 2.3;
      if (flagged.has(o)) { c = COL.flagged; s = 2.4; a = 1; }
      if (rej) { if (rej.has(o)) { a = 0.06; s = 0.8; } else { s *= 1.3; } }
      if (o === S.target && vis.targetMarker) a = 0;
      if (S.sel && o === S.sel.obj && vis.threat) a = 0;
      colArr[i * 3] = c[0]; colArr[i * 3 + 1] = c[1]; colArr[i * 3 + 2] = c[2];
      sizeArr[i] = s; alphaArr[i] = a;
    }
    pgeo.attributes.aColor.needsUpdate = true;
    pgeo.attributes.aSize.needsUpdate = true;
    pgeo.attributes.aAlpha.needsUpdate = true;
  }

  function setObjects(list) {
    S.objects = list;
    if (list.length > cap) { allocPoints(list.length + 16); }
    pgeo.setDrawRange(0, list.length);
    rr = 0; forceFull = true;
    paint();
  }

  /* ----------------------------------------------------------- per frame */
  function eciDirToScene(v) { return new THREE.Vector3(v.x, v.z, -v.y).normalize(); }

  function frameUpdate() {
    earth.setSun(sunDirection(S.simMs, sunV));
    earth.setRotation(E.gmst(S.simMs), performance.now());
    updatePoints();

    const t = S.target;
    live.tpv = t ? E.posVelAt(t, S.simMs) : null;
    if (live.tpv) eciToScene(live.tpv.position, tPos);
    mTarget.visible = !!(vis.targetMarker && live.tpv);
    if (mTarget.visible) mTarget.position.copy(tPos);

    // orbit lines (rebuild every 10 sim-minutes or on change)
    const stale = (line, rec) => line.userData.rec !== rec || Math.abs(S.simMs - line.userData.ms) > 600000;
    oTarget.visible = !!(vis.targetOrbit && t);
    if (oTarget.visible && stale(oTarget, t)) fillOrbit(oTarget, t, S.simMs - t.periodMin * 30000, t.periodMin * 60000);

    // SGP4 step: velocity arrow + radius vector
    arV.visible = lRad.visible = !!(vis.vel && live.tpv);
    if (arV.visible) {
      arV.position.copy(tPos);
      arV.setDirection(eciDirToScene(live.tpv.velocity));
      const L = Math.max(0.12, camera.position.distanceTo(tPos) * 0.22);
      arV.setLength(L, L * 0.2, L * 0.1);
      setLine2(lRad, new THREE.Vector3(), tPos);
    }

    // threat
    const c = S.sel;
    live.threatOk = false;
    if (vis.threat && c && live.tpv) {
      const pv = E.posVelAt(c.obj, S.simMs);
      if (pv) {
        live.threatOk = true;
        eciToScene(pv.position, thPos);
        live.range = E.vec.norm(E.vec.sub(pv.position, live.tpv.position));
        mThreat.position.copy(thPos);
        setLine2(lEnc, tPos, thPos);
      }
    }
    mThreat.visible = lEnc.visible = live.threatOk;
    oThreat.visible = !!(vis.threat && c);
    if (oThreat.visible && stale(oThreat, c.obj)) fillOrbit(oThreat, c.obj, S.simMs - c.obj.periodMin * 30000, c.obj.periodMin * 60000);

    // RIC arrows at the asset
    const ric = !!(vis.ric && c && live.tpv && live.threatOk);
    arR.visible = arI.visible = arC.visible = arM.visible = ric;
    if (ric) {
      const r = live.tpv.position, v = live.tpv.velocity, V3 = E.vec;
      const R = V3.unit(r), Cc = V3.unit(V3.cross(r, v)), I = V3.cross(Cc, R);
      const L = camera.position.distanceTo(tPos) * 0.22;
      [[arR, R, 'R'], [arI, I, 'I'], [arC, Cc, 'C']].forEach(([a, d, k]) => {
        const dir = eciDirToScene(d);
        a.position.copy(tPos); a.setDirection(dir); a.setLength(L, L * 0.18, L * 0.09);
        tips[k].copy(tPos).addScaledVector(dir, L * 1.08);
      });
      const md = thPos.clone().sub(tPos);
      if (md.lengthSq() > 0) { arM.position.copy(tPos); arM.setDirection(md.normalize()); arM.setLength(L * 0.8, L * 0.15, L * 0.08); }
    }

    // post-burn trajectory
    live.postOk = false;
    const showPost = !!(vis.post && S.post && S.plan);
    oPost.visible = mBurn.visible = showPost;
    if (showPost) {
      const start = Math.max(S.plan.burnMs, S.simMs - S.post.periodMin * 30000);
      if (stale(oPost, S.post) || Math.abs(oPost.userData.start - start) > 600000) {
        fillOrbit(oPost, S.post, start, S.post.periodMin * 60000); oPost.userData.start = start;
      }
      const bp = E.posAt(S.target, S.plan.burnMs);
      if (bp) { eciToScene(bp, burnPos); mBurn.position.copy(burnPos); }
      if (S.simMs >= S.plan.burnMs) {
        const pp = E.posAt(S.post, S.simMs);
        if (pp) { eciToScene(pp, postPos); live.postOk = true; mPost.position.copy(postPos); }
      }
    }
    mPost.visible = live.postOk;

    // inspected object
    mInsp.visible = false;
    if (S.insp && S.insp !== S.target) {
      const p = E.posAt(S.insp, S.simMs);
      if (p) { eciToScene(p, inspPos); mInsp.position.copy(inspPos); mInsp.visible = true; }
    }

    // sprite sizes scale with camera distance so they stay readable
    [mTarget, mThreat, mPost, mBurn, mInsp].forEach((m) => {
      if (m.visible) m.scale.setScalar(clamp(camera.position.distanceTo(m.position) * m.userData.k, 0.004, 0.09));
    });
  }

  /* ----------------------------------------------------------------- camera */
  const cam = { follow: false, last: new THREE.Vector3(), anim: null };
  function flyTo(follow, dist) {
    cam.follow = follow;
    const fromC = camera.position.clone(), fromT = controls.target.clone();
    let dir;
    if (follow && S.target) {
      const p = E.posAt(S.target, S.simMs);
      const tp = p ? eciToScene(p) : new THREE.Vector3(1, 0, 0);
      const out = tp.clone().normalize();
      const side = fromC.clone().sub(tp).normalize();
      dir = out.multiplyScalar(0.8).add(side.multiplyScalar(0.55)).add(new THREE.Vector3(0, 0.25, 0)).normalize();
    } else {
      dir = fromC.lengthSq() > 0.01 ? fromC.clone().normalize() : new THREE.Vector3(0, 0.35, 1).normalize();
      if (Math.abs(dir.y) > 0.92) dir.set(0, 0.35, 1).normalize();
    }
    cam.anim = { t0: performance.now(), dur: 1500, fromC, fromT, dir, dist };
  }
  function updateCamera() {
    if (cam.anim) {
      const a = cam.anim;
      const k = ease(Math.min(1, (performance.now() - a.t0) / a.dur));
      const goalT = cam.follow && live.tpv ? tPos.clone() : new THREE.Vector3();
      const goalC = goalT.clone().addScaledVector(a.dir, a.dist);
      controls.target.lerpVectors(a.fromT, goalT, k);
      camera.position.lerpVectors(a.fromC, goalC, k);
      if (k >= 1) { cam.anim = null; cam.last.copy(goalT); }
    } else if (cam.follow && live.tpv) {
      const d = tPos.clone().sub(cam.last);
      camera.position.add(d); controls.target.add(d); cam.last.copy(tPos);
    }
    controls.update();
    if (camera.position.length() < 1.02) camera.position.setLength(1.02);
  }
  controls.addEventListener('start', () => { cam.anim = null; cam.last.copy(tPos); });

  /* -------------------------------------------------------------- visuals */
  function applyVisuals() {
    const g = S.mode === 'guided', st = S.step, t = S.target, c = S.sel;
    vis.targetMarker = !!t && (!g || st >= 1);
    vis.targetOrbit = vis.targetMarker;
    vis.vel = g && st === 1 && !!t;
    vis.shells = g && st === 2 && !!S.coarse;
    vis.threat = !!c && (!g || st >= 3);
    vis.ric = !!c && g && st === 4;
    vis.post = !!S.post && (!g || st === 5);
    vis.dim = g && st === 2;
    controls.autoRotate = g && st === 0 && S.ready;

    shLo.visible = shHi.visible = vis.shells;
    if (vis.shells) {
      const lo = 1 + Math.max(S.coarse.lo, 80) / RE, hi = 1 + S.coarse.hi / RE;
      shLo.scale.setScalar(lo); shHi.scale.setScalar(hi);
    }
    oTarget.userData.rec = oThreat.userData.rec = oPost.userData.rec = null; // force rebuild

    const L = [];
    if (vis.targetMarker) L.push({
      cls: 'target big', pos: () => live.tpv ? tPos : null,
      text: () => { const gd = live.tpv ? E.geodetic(live.tpv.position, S.simMs) : null; return `◎ ${t.name}${gd ? ' · ' + Math.round(gd.alt) + ' km' : ''}`; }
    });
    if (vis.threat) L.push({ cls: 'threat', pos: () => live.threatOk ? thPos : null, text: () => `⚠ ${c.obj.name} · ${km(live.range)}` });
    if (vis.post) {
      L.push({ cls: 'green', pos: () => live.postOk ? postPos : null, text: () => `POST-BURN · miss ${km(S.verified ? S.verified.d : null)}` });
      L.push({ cls: 'green', pos: () => burnPos, text: () => `BURN ${hms(S.plan.burnMs)} · ${dvFmt(S.plan.dv)}` });
    }
    if (vis.ric && c) {
      L.push({ cls: '', pos: () => tips.R, text: `R ${kmS(c.ric.r)}` });
      L.push({ cls: '', pos: () => tips.I, text: `I ${kmS(c.ric.i)}` });
      L.push({ cls: '', pos: () => tips.C, text: `C ${kmS(c.ric.c)}` });
    }
    if (vis.shells) {
      L.push({ cls: 'info', pos: () => { shellLbl.hi.set(0, 1 + S.coarse.hi / RE, 0); return shellLbl.hi; }, text: `upper bound ${Math.round(S.coarse.hi)} km` });
      L.push({ cls: 'info', pos: () => { shellLbl.lo.set(0, -(1 + Math.max(S.coarse.lo, 80) / RE), 0); return shellLbl.lo; }, text: `lower bound ${Math.round(S.coarse.lo)} km` });
    }
    if (S.insp && S.insp !== t) L.push({ cls: 'info', pos: () => mInsp.visible ? inspPos : null, text: S.insp.name });
    setLabels(L);
    paint();
  }

  /* ----------------------------------------------------------- inspector */
  function openInspector(o) {
    S.insp = o;
    dom.insp.hidden = false;
    dom.inspName.textContent = o.name;
    fillInspector();
    applyVisuals();
  }
  function fillInspector() {
    const o = S.insp; if (!o) return;
    const pv = E.posVelAt(o, S.simMs);
    const gd = pv ? E.geodetic(pv.position, S.simMs) : null;
    const ageH = (S.simMs - o.epochMs) / 3600e3;
    const cell = (k, v) => `<div><span>${k}</span>${v}</div>`;
    dom.inspGrid.innerHTML = [
      cell('NORAD ID', o.id), cell('Catalogue', esc(groupShort(o.group))),
      cell('Intl. designator', esc(o.intl || '—')), cell('Type', o.kind === 'debris' ? 'Debris' : o.kind === 'synthetic' ? 'Synthetic' : 'Satellite'),
      cell('Inclination', o.incl.toFixed(2) + '°'), cell('Eccentricity', o.ecc.toFixed(5)),
      cell('Perigee', Math.round(o.perigee) + ' km'), cell('Apogee', Math.round(o.apogee) + ' km'),
      cell('Period', o.periodMin.toFixed(1) + ' min'), cell('B* drag', o.bstar.toExponential(2)),
      cell('Altitude now', gd ? Math.round(gd.alt) + ' km' : 'decayed'), cell('Speed now', pv ? E.vec.norm(pv.velocity).toFixed(3) + ' km/s' : '—'),
      cell('Lat / Lon', gd ? `${gd.lat.toFixed(2)}°, ${gd.lon.toFixed(2)}°` : '—'), cell('TLE age', (ageH >= 0 ? '' : '−') + Math.abs(ageH).toFixed(1) + ' h'),
      `<div class="tle">${esc(o.l1)}<br>${esc(o.l2)}</div>`
    ].join('');
    dom.inspTarget.disabled = o === S.target;
    dom.inspTarget.innerHTML = o === S.target ? '<i class="fa-solid fa-shield-halved"></i> This is the protected asset' : '<i class="fa-solid fa-crosshairs"></i> Make this the protected asset';
  }
  dom.inspClose.addEventListener('click', () => { S.insp = null; dom.insp.hidden = true; applyVisuals(); });
  dom.inspTarget.addEventListener('click', () => { if (S.insp && !S.busy) setTarget(S.insp); });

  // click-to-pick (screen-space nearest point)
  let down = null;
  canvas.addEventListener('pointerdown', (e) => { down = { x: e.clientX, y: e.clientY }; });
  canvas.addEventListener('pointerup', (e) => {
    if (down && Math.hypot(e.clientX - down.x, e.clientY - down.y) < 5) pick(e);
    down = null;
  });
  function pick(e) {
    if (!S.ready) return;
    const r = canvas.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top;
    const w = r.width, h = r.height;
    let best = -1, bd = 14 * 14;
    const v = new THREE.Vector3();
    for (let i = 0; i < S.objects.length; i++) {
      if (!OK[i]) continue;
      if (alphaArr[i] < 0.05 && S.objects[i] !== S.target && !(S.sel && S.objects[i] === S.sel.obj)) continue;
      v.set(posArr[i * 3], posArr[i * 3 + 1], posArr[i * 3 + 2]).project(camera);
      if (v.z > 1) continue;
      const dx = (v.x + 1) / 2 * w - mx, dy = (1 - v.y) / 2 * h - my, d2 = dx * dx + dy * dy;
      if (d2 < bd) {
        v.set(posArr[i * 3], posArr[i * 3 + 1], posArr[i * 3 + 2]);
        if (!occluded(v)) { bd = d2; best = i; }
      }
    }
    if (best >= 0) openInspector(S.objects[best]);
  }

  /* -------------------------------------------------------------- targets */
  function defaultTarget() {
    return S.base.find((o) => o.id === 25544) || S.base.find((o) => /^ISS/.test(o.name)) ||
      S.base.find((o) => o.kind === 'active') || S.base[0];
  }
  function populateTargets() {
    const sel = dom.targetSel;
    sel.innerHTML = '';
    GROUP_ORDER.filter((g) => !DEBRIS.has(g)).forEach((g) => {
      const og = document.createElement('optgroup');
      og.label = E.GROUPS[g].label;
      S.base.forEach((o, i) => {
        if (o.group !== g) return;
        const op = document.createElement('option');
        op.value = i; op.textContent = `${o.name} · ${Math.round((o.perigee + o.apogee) / 2)} km`;
        og.appendChild(op);
      });
      if (og.children.length) sel.appendChild(og);
    });
    syncTargetSel();
  }
  function syncTargetSel() {
    const sel = dom.targetSel;
    sel.querySelectorAll('option[data-custom]').forEach((o) => o.remove());
    const idx = S.base.indexOf(S.target);
    if (idx >= 0 && sel.querySelector(`option[value="${idx}"]`)) sel.value = String(idx);
    else if (S.target) {
      const op = document.createElement('option');
      op.value = idx >= 0 ? idx : 'custom'; op.dataset.custom = '1'; op.textContent = '◎ ' + S.target.name;
      sel.insertBefore(op, sel.firstChild); sel.value = op.value;
    }
  }
  function setTarget(o) {
    S.target = o;
    invalidate();
    syncTargetSel();
    if (S.insp) fillInspector();
    log(`target ← ${o.name} (NORAD ${o.id}) · ${Math.round(o.perigee)}–${Math.round(o.apogee)} km · i=${o.incl.toFixed(1)}°`, 'c-cmd');
    if (S.mode === 'guided') goStep(clamp(S.step, 1, 2));
    else { applyVisuals(); flyTo(true, 1.4); }
  }
  dom.targetSel.addEventListener('change', () => {
    const o = S.base[+dom.targetSel.value];
    if (o && o !== S.target && !S.busy) setTarget(o);
  });

  /* --------------------------------------------------------- invalidation */
  function invalidate() {
    S.coarse = S.result = S.sel = S.plan = S.post = S.verified = null;
    if (S.objects.length !== S.base.length) setObjects(S.base.slice());
    renderConjList(); renderChart(); renderMitig();
    dom.hudCenter.hidden = true;
  }

  /* ------------------------------------------------------------ screening */
  function setBusyUI(on, f = 0) {
    S.progress = f;
    const pct = Math.round(f * 100);
    dom.runBtn.disabled = on || !S.ready;
    dom.targetSel.disabled = on;
    dom.runBtn.innerHTML = on ? `<i class="fa-solid fa-spinner fa-spin"></i> Screening… ${pct}%` : '<i class="fa-solid fa-satellite"></i> Run full screening';
    if (S.mode === 'guided') {
      dom.next.disabled = on; dom.prev.disabled = on;
      if (on) dom.next.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Screening ${pct}%`;
    }
  }

  async function runScreening() {
    if (S.busy || !S.target) return null;
    invalidate();
    S.busy = true;
    const hours = +dom.winIn.value, stepSec = +dom.stepIn.value, thr = +dom.thrIn.value;
    const startMs = Math.round(S.simMs / 1000) * 1000;
    let list = S.base.slice();
    if (dom.injectIn.checked) {
      const extra = [];
      E.injectThreats(S.target, extra, startMs, hours);
      extra.forEach((o) => { o.kind = 'synthetic'; o.group = 'synthetic'; });
      list = list.concat(extra);
      log(`+ injected ${extra.length} SYNTHETIC crossing objects (stress test)`, 'c-warn');
    }
    setObjects(list);
    log(`$ screen --target ${S.target.id} --window ${hours}h --step ${stepSec}s --threshold ${thr}km`, 'c-cmd');
    S.coarse = E.coarseFilter(S.target, S.objects, thr);
    log(`stage 1 · apogee/perigee filter: ${S.coarse.candidates.length.toLocaleString()} candidates, ${S.coarse.rejected.length.toLocaleString()} rejected`);
    setBusyUI(true, 0);
    renderExplain();
    let res;
    try {
      res = await E.screen(S.target, S.objects, {
        startMs, hours, stepSec, thresholdKm: thr,
        onProgress: (f) => { setBusyUI(true, f); }
      });
    } catch (err) {
      log('✕ screening failed: ' + err.message, 'c-err');
      S.busy = false; setBusyUI(false); renderExplain();
      return null;
    }
    S.result = res; S.coarse = res.coarse;
    S.winStart = startMs; S.winLen = hours * 3600e3;
    log(`stage 2 · ${res.evals.toLocaleString()} SGP4 evaluations in ${res.elapsedMs} ms`);
    log(`✔ ${res.conjunctions.length} closest approaches · ${res.flagged} within ${thr} km` + (res.coorbital.length ? ` · ${res.coorbital.length} co-orbital/docked ignored` : ''), res.flagged ? 'c-warn' : 'c-ok');
    S.busy = false;
    setBusyUI(false);
    renderConjList();
    if (res.conjunctions.length) selectConj(res.conjunctions[0], true);
    else applyVisuals();
    renderExplain();
    return res;
  }
  dom.runBtn.addEventListener('click', async () => {
    const r = await runScreening();
    if (!r) return;
    if (S.mode === 'guided') goStep(3);
    else if (S.sel) { jumpTo(S.sel.tcaMs - 5 * 60000); setSpeed(10); setPlaying(true); flyTo(true, 1.0); }
  });

  /* ---------------------------------------------------- conjunction select */
  function selectConj(c, quiet) {
    if (!S.result) return;
    S.sel = c;
    const safe = +dom.safeIn.value, mass = massOf(S.target);
    let plan = E.planManeuver(S.target, c, safe, S.result.startMs, mass);
    let post = null, ver = null;
    if (plan.required && plan.dv > 0) {
      let dv = plan.dv;
      for (let it = 0; it < 5; it++) {
        post = E.applyManeuver(S.target, plan.burnMs, dv, plan.prograde);
        if (!post) break;
        ver = E.verifyMiss(post, c.obj, c.tcaMs);
        if (ver.d >= safe) break;
        dv *= Math.min(3, Math.max(1.3, safe * 1.1 / Math.max(ver.d, 0.05)));
      }
      plan = Object.assign({}, plan, { dv, fuelKg: mass * (1 - Math.exp(-dv / (220 * 9.80665))) });
    }
    S.plan = plan; S.post = post; S.verified = ver;
    if (!quiet) log(`select ${c.obj.name} · TCA ${hms(c.tcaMs)} · miss ${km(c.miss)} · Pc ${pcFmt(c.pc)}`, 'c-cmd');
    if (plan.required) log(`  plan: ${plan.prograde ? 'prograde' : 'retrograde'} Δv ${dvFmt(plan.dv)} at ${hms(plan.burnMs)} → SGP4-verified miss ${km(ver ? ver.d : null)}`, ver && ver.d >= safe ? 'c-ok' : 'c-warn');
    else log(`  no manoeuvre needed (miss ≥ ${safe} km)`, 'c-ok');
    dom.conjList.querySelectorAll('.conj').forEach((b) => b.classList.toggle('sel', b._c === c));
    renderChart(); renderMitig(); applyVisuals(); renderExplain();
  }

  function renderConjList() {
    const el = dom.conjList;
    if (!S.result) {
      el.innerHTML = '<p class="empty">Run the screening to list close approaches.</p>';
      dom.conjMeta.textContent = '';
      return;
    }
    const r = S.result;
    dom.conjMeta.textContent = `${r.flagged} ≤ ${r.thresholdKm} km · ${r.conjunctions.length} listed`;
    if (!r.conjunctions.length) { el.innerHTML = '<p class="empty">No close approaches found in this window.</p>'; return; }
    el.innerHTML = '';
    r.conjunctions.forEach((c) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'conj' + (c === S.sel ? ' sel' : '');
      b._c = c;
      b.innerHTML = `<span class="badge" style="background:${c.risk.color}">${c.risk.label}</span>` +
        `<div style="min-width:0"><div class="nm">${esc(c.obj.name)}</div>` +
        `<div class="meta">TCA ${hms(c.tcaMs)} · v<sub>rel</sub> ${c.relVel.toFixed(2)} km/s · Pc ${pcFmt(c.pc)}</div></div>` +
        `<div class="dist">${km(c.miss)}<small>miss</small></div>`;
      b.addEventListener('click', () => {
        selectConj(c);
        if (S.mode === 'explore' || S.step >= 3) { jumpTo(c.tcaMs - 5 * 60000); setSpeed(10); setPlaying(true); if (S.mode === 'explore') flyTo(true, 1.0); }
      });
      el.appendChild(b);
    });
  }

  /* ----------------------------------------------------------------- chart */
  let chart = null;
  function renderChart() {
    const c = S.sel;
    if (!c || !window.Chart) {
      if (chart) { chart.data.datasets.forEach((d) => { d.data = []; }); chart.update(); }
      dom.chartMeta.textContent = '';
      return;
    }
    const spanMin = 45, a = c.tcaMs - spanMin * 60000, b = c.tcaMs + spanMin * 60000;
    const toXY = (p) => ({ x: (p.ms - c.tcaMs) / 60000, y: p.d == null ? null : Math.max(p.d, 0.01) });
    const s1 = E.distanceSeries(S.target, c.obj, a, b, 300).map(toXY);
    const s2 = S.post ? E.distanceSeries(S.post, c.obj, Math.max(a, S.plan.burnMs), b, 300).map(toXY) : [];
    const thr = S.result.thresholdKm, safe = +dom.safeIn.value;
    const flat = (y) => [{ x: -spanMin, y }, { x: spanMin, y }];
    const data = {
      datasets: [
        { label: 'Original', data: s1, borderColor: '#ff4d5e', backgroundColor: 'rgba(255,77,94,.12)', borderWidth: 2, pointRadius: 0, fill: false, tension: 0.2 },
        { label: 'Post-burn', data: s2, borderColor: '#3dff9a', borderWidth: 2, pointRadius: 0, tension: 0.2 },
        { label: `Threshold ${thr} km`, data: flat(thr), borderColor: '#ffb020', borderDash: [5, 4], borderWidth: 1, pointRadius: 0 },
        { label: `Safe ${safe} km`, data: flat(safe), borderColor: '#38e1ff', borderDash: [2, 4], borderWidth: 1, pointRadius: 0 }
      ]
    };
    dom.chartMeta.textContent = `TCA ±${spanMin} min · log scale`;
    if (chart) { chart.data = data; chart.update(); return; }
    chart = new window.Chart(dom.chartCanvas, {
      type: 'line', data,
      options: {
        responsive: true, maintainAspectRatio: false, animation: false, spanGaps: true,
        interaction: { mode: 'nearest', intersect: false, axis: 'x' },
        scales: {
          x: { type: 'linear', min: -spanMin, max: spanMin, title: { display: true, text: 'minutes from TCA', color: '#8b98b8', font: { size: 10 } }, ticks: { color: '#8b98b8', font: { size: 10 } }, grid: { color: 'rgba(120,170,255,.08)' } },
          y: { type: 'logarithmic', title: { display: true, text: 'range (km)', color: '#8b98b8', font: { size: 10 } }, ticks: { color: '#8b98b8', font: { size: 10 }, callback: (v) => { const l = Math.log10(v); return Math.abs(l - Math.round(l)) < 1e-6 ? v.toLocaleString() : ''; } }, grid: { color: 'rgba(120,170,255,.08)' } }
        },
        plugins: {
          legend: { labels: { color: '#c3cde6', boxWidth: 10, boxHeight: 2, font: { size: 10 } } },
          tooltip: { callbacks: { title: (it) => `${it[0].parsed.x >= 0 ? '+' : ''}${it[0].parsed.x.toFixed(1)} min`, label: (it) => `${it.dataset.label}: ${km(it.parsed.y)}` } }
        }
      }
    });
  }

  /* ------------------------------------------------------------ mitigation */
  function renderMitig() {
    const el = dom.mitig, c = S.sel, p = S.plan;
    if (!c || !p) { el.innerHTML = '<p class="empty">Select a conjunction to plan an avoidance manoeuvre.</p>'; return; }
    if (!p.required) {
      el.innerHTML = `<div class="verdict ok"><i class="fa-solid fa-circle-check"></i> Miss distance <b>${km(c.miss)}</b> is already above the ${p.safeKm} km safe distance — no manoeuvre required. Keep monitoring.</div>`;
      return;
    }
    const ver = S.verified ? S.verified.d : null;
    const ok = ver != null && ver >= p.safeKm * 0.98;
    el.innerHTML = `<div class="mgrid">
        <div><span>Δv</span><b>${dvFmt(p.dv)}</b></div>
        <div><span>Direction</span><b>${p.prograde ? 'Prograde' : 'Retrograde'}</b></div>
        <div><span>Burn (UTC)</span><b>${hms(p.burnMs)}</b></div>
        <div><span>Lead time</span><b>${dur(p.leadS * 1000).slice(1)}</b></div>
        <div><span>Fuel (Isp 220 s)</span><b>${fuelFmt(p.fuelKg)}</b></div>
        <div><span>Miss → after</span><b>${km(c.miss)} → <span style="display:inline;color:${ok ? '#3dff9a' : '#ff4d5e'};font-size:inherit;text-transform:none">${km(ver)}</span></b></div>
      </div>
      <div class="verdict ${ok ? 'ok' : 'bad'}">${ok
        ? `<i class="fa-solid fa-shield-halved"></i> SGP4 re-propagation confirms the encounter is cleared: new miss distance <b>${km(ver)}</b> ≥ ${p.safeKm} km safe distance.`
        : `<i class="fa-solid fa-triangle-exclamation"></i> The linear plan did not fully clear the encounter (verified ${km(ver)}). Consider an earlier burn or a larger safe distance.`}</div>`;
  }
  dom.safeIn.addEventListener('change', () => { if (S.sel) selectConj(S.sel); });

  /* ------------------------------------------------------------ parameters */
  dom.winIn.addEventListener('input', () => { dom.winOut.textContent = dom.winIn.value + ' h'; });
  dom.thrIn.addEventListener('input', () => { dom.thrOut.textContent = dom.thrIn.value + ' km'; });
  function paramsChanged() {
    if (S.busy || !S.ready) return;
    const hadResult = !!S.result;
    invalidate();
    if (hadResult) log('parameters changed — run the screening again', 'c-dim');
    if (S.mode === 'guided' && S.step >= 2) goStep(2);
    else applyVisuals();
  }
  [dom.winIn, dom.thrIn, dom.stepIn, dom.injectIn].forEach((el) => el.addEventListener('change', paramsChanged));

  function renderCatalogs() {
    dom.catalogs.innerHTML = S.catalogs.map((c) =>
      `<span class="cat ${c.source}" title="source: ${c.source}"><b>${c.n.toLocaleString()}</b> ${esc(groupShort(c.group))}</span>`).join('');
  }

  /* ----------------------------------------------------------------- steps */
  const row = (k, v, cls = '') => `<div class="k ${cls}"><span>${k}</span><b>${v}</b></div>`;
  const noConj = () => row('Conjunctions', 'none in window', 'ok');

  const STEPS = [
    {
      title: 'Ingest from the API',
      body: () => `OrbitGuard calls the public <b>CelesTrak GP API</b> once per catalogue group and receives every object as a <b>Two-Line Element set (TLE)</b>. Each dot is one catalogued object: <span style="color:#ff8a3d">orange</span> = fragments from the Fengyun‑1C, Cosmos‑2251 and Iridium‑33 break-ups, <span style="color:#38e1ff">cyan</span> = active satellites and stations. Drag to rotate, scroll to zoom, click any dot to inspect it.`,
      ex: () => S.catalogs.map((c) => row(`${groupShort(c.group)} <small class="muted">(${c.source})</small>`, c.n.toLocaleString(), c.source === 'simulated' ? 'amb' : '')).join('') +
        row('Total unique objects', S.base.length.toLocaleString()),
      formula: () => S.target ? `GET ${E.API_BASE}?GROUP=stations&FORMAT=tle\n${S.target.name}\n${S.target.l1}\n${S.target.l2}` : '',
      next: 'Next: SGP4',
      enter: () => { flyTo(false, 4.4); setPlaying(true); }
    },
    {
      title: 'Decode & propagate with SGP4',
      body: () => `Each TLE is decoded into mean orbital elements and fed to <b>SGP4</b>, the standard NORAD propagator. It returns position <b>r</b> and velocity <b>v</b> in the TEME inertial frame at any instant, modelling Earth's oblateness (J2) and atmospheric drag (B*). We now follow the protected asset <b>${esc(S.target.name)}</b>: the white ring is one full orbit, the cyan arrow its velocity, the cyan line its radius vector.`,
      ex: () => {
        const pv = live.tpv || E.posVelAt(S.target, S.simMs); if (!pv) return row('State', 'decayed', 'warn');
        const gd = E.geodetic(pv.position, S.simMs), t = S.target;
        return row('|r| (from Earth centre)', E.vec.norm(pv.position).toFixed(1) + ' km') +
          row('|v| speed', E.vec.norm(pv.velocity).toFixed(3) + ' km/s') +
          row('Altitude', gd.alt.toFixed(1) + ' km') +
          row('Lat / Lon', `${gd.lat.toFixed(2)}°, ${gd.lon.toFixed(2)}°`) +
          row('Inclination · period', `${t.incl.toFixed(2)}° · ${t.periodMin.toFixed(1)} min`);
      },
      formula: () => `(r, v) = SGP4(TLE, t − t_epoch)\nT = 2π·√(a³/μ) = ${S.target.periodMin.toFixed(1)} min   B* = ${S.target.bstar.toExponential(2)}`,
      next: 'Next: Filter',
      enter: () => { flyTo(true, 0.9); setPlaying(true); }
    },
    {
      title: 'Coarse altitude filter',
      body: () => `Comparing every object at every time step is expensive. Stage 1 keeps only objects whose <b>perigee–apogee band overlaps</b> the asset's band, padded by the threshold + 15 km. The two shells show that band; everything that fades out can never come close to <b>${esc(S.target.name)}</b> and is skipped.`,
      ex: () => {
        const c = S.coarse; if (!c) return '';
        const tot = c.candidates.length + c.rejected.length;
        return row('Altitude band', `${Math.round(c.lo)} – ${Math.round(c.hi)} km`) +
          row('Candidates kept', c.candidates.length.toLocaleString(), 'amb') +
          row('Rejected', c.rejected.length.toLocaleString()) +
          row('Work saved', (tot ? (100 * c.rejected.length / tot).toFixed(1) : 0) + ' %', 'ok');
      },
      formula: () => `keep if  apogee_obj ≥ perigee_asset − pad\n    and  perigee_obj ≤ apogee_asset + pad\npad = threshold + 15 km = ${S.coarse ? S.coarse.pad : '—'} km`,
      next: 'Next: Screen',
      enter: () => { flyTo(false, 3.3); setPlaying(true); }
    },
    {
      title: 'Fine screening & TCA',
      body: () => `For each candidate, SGP4 positions are sampled every <b>${dom.stepIn.value} s</b> over the next <b>${dom.winIn.value} h</b>. When the distance reaches a local minimum, a golden-section search pins down the exact <b>Time of Closest Approach (TCA)</b>. The red line links the asset to the closest object — watch the range shrink as the clock runs to TCA. <span style="color:#ffb020">Amber</span> dots are other objects inside the threshold.`,
      ex: () => {
        const r = S.result;
        if (S.busy) return row('Screening', Math.round(S.progress * 100) + ' %', 'amb');
        if (!r) return '';
        const c = S.sel;
        return row('Samples per object', (Math.floor(r.hours * 3600 / r.stepSec) + 1).toLocaleString()) +
          row('SGP4 evaluations', r.evals.toLocaleString()) +
          row('Elapsed', r.elapsedMs.toLocaleString() + ' ms') +
          row(`Within ${r.thresholdKm} km`, r.flagged, r.flagged ? 'warn' : 'ok') +
          (c ? row('Closest · TCA', `${km(c.miss)} · ${hms(c.tcaMs)}`, 'warn') + row('Live range', km(live.range)) : noConj());
      },
      formula: () => `d(t) = |r_asset(t) − r_obj(t)|\nTCA = argmin d(t)   (golden-section, ±5 s)`,
      next: 'Next: Risk',
      enter: () => { if (S.sel) { jumpTo(S.sel.tcaMs - 5 * 60000); setSpeed(10); } setPlaying(true); flyTo(true, 1.0); }
    },
    {
      title: 'Risk scoring',
      body: () => S.sel ? `At TCA the miss vector (white) is split into the asset's <b>Radial / In-track / Cross-track</b> frame — the pink, amber and violet arrows. Relative speed tells us how violent an impact would be, and a Gaussian model estimates the <b>probability of collision (Pc)</b>: ≥ 1e‑4 is <b style="color:#ff4d5e">HIGH</b> (manoeuvre), ≥ 1e‑6 <b style="color:#ffb020">MEDIUM</b> (monitor).` : 'No close approach was found in this window, so there is nothing to score. Try a longer window, a larger threshold or enable the synthetic crossing objects.',
      ex: () => {
        const c = S.sel; if (!c) return noConj();
        return row('Object', esc(c.obj.name.length > 26 ? c.obj.name.slice(0, 25) + '…' : c.obj.name)) +
          row('TCA (UTC)', hms(c.tcaMs)) + row('Miss distance', km(c.miss), 'warn') +
          row('R · I · C', `${c.ric.r.toFixed(2)} · ${c.ric.i.toFixed(2)} · ${c.ric.c.toFixed(2)} km`) +
          row('Relative speed', c.relVel.toFixed(3) + ' km/s') +
          row('Pc', pcFmt(c.pc), c.risk.key === 'high' ? 'warn' : 'amb') +
          `<div class="k"><span>Risk tier</span><b style="color:${c.risk.color}">${c.risk.label}</b></div>`;
      },
      formula: () => `Pc ≈ HBR² / (2σ²) · exp(−d² / (2σ²))\nHBR = 50 m, σ = 1 km (TLEs carry no covariance)`,
      next: 'Next: Mitigate',
      enter: () => { if (S.sel) jumpTo(S.sel.tcaMs); setPlaying(false); flyTo(true, 0.3); }
    },
    {
      title: 'Plan the avoidance burn',
      body: () => !S.sel ? 'No conjunction selected — nothing to mitigate.' : S.plan && S.plan.required
        ? `OrbitGuard computes the smallest <b>along-track burn</b> that opens the miss distance to the safe value (${dom.safeIn.value} km). A tiny speed change alters the orbital period, so the asset reaches the crossing point slightly earlier or later. The new orbit (<span style="color:#3dff9a">green</span>) is re-fitted and <b>re-propagated with SGP4</b> to verify the encounter is cleared.`
        : `The miss distance is already above the ${dom.safeIn.value} km safe distance, so no burn is required — the operator just keeps monitoring.`,
      ex: () => {
        const c = S.sel, p = S.plan; if (!c || !p) return noConj();
        if (!p.required) return row('Manoeuvre', 'not required', 'ok');
        const ver = S.verified ? S.verified.d : null, ok = ver != null && ver >= p.safeKm * 0.98;
        return row('Δv', dvFmt(p.dv) + (p.prograde ? ' prograde' : ' retrograde'), 'amb') +
          row('Burn time (UTC)', `${hms(p.burnMs)} · ${dur(c.tcaMs - p.burnMs).slice(1)} before TCA`) +
          row('Along-track shift', p.need.toFixed(2) + ' km') +
          row('Fuel estimate', fuelFmt(p.fuelKg)) +
          row('Miss before', km(c.miss), 'warn') +
          row('Miss after (SGP4)', km(ver), ok ? 'ok' : 'warn');
      },
      formula: () => S.plan && S.plan.required ? `Δs ≈ 3 · Δv · t_lead   (Clohessy–Wiltshire)\nΔv ≈ ${S.plan.need.toFixed(2)} km / (3 × ${Math.round(S.plan.leadS)} s), then SGP4 re-check` : '',
      next: 'Open free explore',
      enter: () => { if (S.sel) jumpTo(S.sel.tcaMs - 4 * 60000); setSpeed(10); setPlaying(true); flyTo(true, 0.55); }
    }
  ];

  function renderExplain() {
    if (!S.ready) return;
    const st = STEPS[S.step];
    dom.steps.querySelectorAll('li').forEach((li, i) => {
      li.classList.toggle('active', i === S.step);
      li.classList.toggle('done', i < S.step);
    });
    dom.exKicker.textContent = `STEP ${S.step + 1} / ${STEPS.length}`;
    dom.exTitle.textContent = st.title;
    dom.exBody.innerHTML = S.target || S.step === 0 ? st.body() : '';
    refreshEx();
    if (!S.busy) {
      dom.next.disabled = false; dom.prev.disabled = S.step === 0;
      dom.next.innerHTML = `${st.next} <i class="fa-solid fa-arrow-right"></i>`;
    }
  }
  function refreshEx() {
    if (!S.ready || S.mode !== 'guided') return;
    const st = STEPS[S.step];
    try {
      dom.ex3d.innerHTML = st.ex();
      dom.exFormula.textContent = st.formula();
    } catch (e) { /* data not ready yet */ }
  }

  let stepToken = 0;
  async function goStep(i) {
    if (!S.ready || S.busy) return;
    i = clamp(i, 0, STEPS.length - 1);
    const token = ++stepToken;
    S.step = i;
    if (i >= 1 && !S.target) S.target = defaultTarget();
    if (i >= 2 && !S.coarse) S.coarse = E.coarseFilter(S.target, S.objects, +dom.thrIn.value);
    applyVisuals(); renderExplain();
    if (i >= 3 && !S.result) { await runScreening(); if (token !== stepToken) return; }
    if (i >= 4 && !S.sel && S.result && S.result.conjunctions.length) selectConj(S.result.conjunctions[0], true);
    STEPS[i].enter();
    applyVisuals(); renderExplain();
  }
  dom.steps.querySelectorAll('li').forEach((li) => li.addEventListener('click', () => goStep(+li.dataset.step)));
  dom.next.addEventListener('click', () => { if (S.step < STEPS.length - 1) goStep(S.step + 1); else setMode('explore'); });
  dom.prev.addEventListener('click', () => goStep(S.step - 1));

  /* ------------------------------------------------------------------ mode */
  function setMode(m) {
    S.mode = m;
    dom.labRoot.classList.toggle('explore', m === 'explore');
    document.querySelectorAll('.mode-btn').forEach((b) => {
      const on = b.dataset.mode === m;
      b.classList.toggle('active', on); b.setAttribute('aria-selected', on);
    });
    if (!S.ready) return;
    if (m === 'guided') goStep(S.step);
    else {
      if (!S.target) S.target = defaultTarget();
      applyVisuals();
      flyTo(true, S.sel ? 1.0 : 1.6);
      log('free explore: pick an asset, tune the parameters and run the screening', 'c-dim');
    }
  }
  document.querySelectorAll('.mode-btn').forEach((b) => b.addEventListener('click', () => setMode(b.dataset.mode)));

  /* -------------------------------------------------------------- timeline */
  function setPlaying(on) {
    S.playing = on;
    dom.play.innerHTML = on ? '<i class="fa-solid fa-pause"></i>' : '<i class="fa-solid fa-play"></i>';
  }
  function setSpeed(v) { S.speed = v; dom.speed.value = String(v); }
  dom.play.addEventListener('click', () => setPlaying(!S.playing));
  dom.speed.addEventListener('change', () => { S.speed = +dom.speed.value; });
  dom.now.addEventListener('click', () => { jumpTo(S.result ? S.winStart : Date.now()); if (!S.result) S.winStart = S.simMs; });
  dom.cam.addEventListener('click', () => { if (S.target) flyTo(true, 0.8); });
  dom.scrub.addEventListener('pointerdown', () => { S.scrubbing = true; });
  window.addEventListener('pointerup', () => { S.scrubbing = false; });
  dom.scrub.addEventListener('input', () => { jumpTo(S.winStart + (+dom.scrub.value / 1000) * S.winLen); });

  function updateTimeline() {
    dom.simTime.textContent = hms(S.simMs);
    dom.simDate.textContent = `${ymd(S.simMs)} UTC · T${dur(S.simMs - S.winStart)}`;
    if (!S.scrubbing) dom.scrub.value = String(clamp((S.simMs - S.winStart) / S.winLen * 1000, 0, 1000));
  }
  function updateHud() {
    const c = S.sel, el = dom.hudCenter;
    if (!c || !vis.threat) { el.hidden = true; return; }
    el.hidden = false;
    const postActive = S.post && vis.post && S.simMs >= S.plan.burnMs;
    if (postActive) {
      el.className = 'hud-center ok';
      el.textContent = `✔ Avoidance burn applied · ${c.obj.name} · new miss ${km(S.verified.d)} · TCA ${dur(S.simMs - c.tcaMs)}`;
    } else {
      el.className = 'hud-center' + (c.miss > S.result.thresholdKm ? ' ok' : '');
      const dt = c.tcaMs - S.simMs;
      el.textContent = `${c.miss <= S.result.thresholdKm ? '⚠ CONJUNCTION' : 'Closest approach'} · ${c.obj.name} · ${dt >= 0 ? 'TCA in ' + dur(dt).slice(1) : 'TCA ' + dur(-dt).slice(1) + ' ago'} · range ${km(live.range)} · ${c.risk.label}`;
    }
  }

  /* ------------------------------------------------------------------ boot */
  async function boot() {
    if (S.booting || S.ready) return;
    S.booting = true;
    dom.bootBtn.disabled = true;
    dom.bootBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Connecting to CelesTrak…';
    log('$ orbitguard ingest --source celestrak-gp --format tle', 'c-cmd');
    const results = await Promise.all(GROUP_ORDER.map(async (g) => {
      log(`GET ${E.API_BASE}?GROUP=${g}&FORMAT=tle`, 'c-dim');
      try {
        const r = await E.fetchGroup(g);
        log(`← ${r.source === 'cache' ? 'CACHE' : r.status + ' OK'} ${g}: ${r.objects.length.toLocaleString()} objects · ${(r.bytes / 1024).toFixed(0)} kB${r.ms ? ' · ' + r.ms + ' ms' : ''}`, 'c-ok');
        return r;
      } catch (err) {
        log(`✕ ${g}: ${err.name === 'AbortError' ? 'timeout' : (err.message || 'network error')} → simulated catalogue`, 'c-warn');
        return E.syntheticGroup(g);
      }
    }));
    const seen = new Set(), base = [];
    results.forEach((r) => {
      r.objects.forEach((o) => {
        const key = o.id + '|' + o.l2.substring(8, 63);
        if (seen.has(key)) return;
        seen.add(key);
        o.group = r.group; o.kind = DEBRIS.has(r.group) ? 'debris' : 'active'; o.source = r.source;
        base.push(o);
      });
    });
    S.catalogs = results.map((r) => ({ group: r.group, n: r.objects.length, source: r.source }));
    const srcs = new Set(results.map((r) => r.source));
    const badge = srcs.size === 1 ? [...srcs][0] : srcs.has('simulated') ? 'simulated' : srcs.has('live') ? 'live' : 'cache';
    dom.srcBadge.className = 'src-badge ' + badge;
    dom.srcBadge.textContent = srcs.size === 1 ? badge : 'mixed';
    if (srcs.has('simulated')) log('note: SIMULATED objects are a labelled fallback — real data returns once the API is reachable', 'c-warn');
    log(`✔ catalogue ready: ${base.length.toLocaleString()} unique objects decoded`, 'c-ok');

    S.base = base;
    allocPoints(base.length + 16);
    setObjects(base.slice());
    S.target = defaultTarget();
    S.simMs = Date.now(); S.winStart = S.simMs;
    populateTargets(); renderCatalogs();
    S.ready = true; S.booting = false;
    dom.runBtn.disabled = false;
    dom.boot.classList.add('hide');
    setTimeout(() => { dom.boot.hidden = true; }, 900);
    if (S.mode === 'guided') await goStep(0); else setMode('explore');
  }
  dom.bootBtn.addEventListener('click', boot);

  /* ------------------------------------------------------------------ loop */
  function resize() {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  new ResizeObserver(resize).observe(canvas);
  resize();

  let visible = true;
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; }).observe(dom.viewport);

  let lastT = performance.now(), uiTick = 0;
  function loop(now) {
    requestAnimationFrame(loop);
    const dt = Math.min(0.1, (now - lastT) / 1000); lastT = now;
    if (!visible) return;
    if (S.playing && !S.scrubbing) S.simMs += dt * 1000 * S.speed;
    frameUpdate();
    updateCamera();
    updateLabels();
    if ((uiTick++ % 6) === 0) { updateTimeline(); updateHud(); }
    if (uiTick % 20 === 0) { refreshEx(); if (S.insp && !dom.insp.hidden) fillInspector(); }
    renderer.render(scene, camera);
  }
  requestAnimationFrame(loop);
  setPlaying(true);
  applyVisuals();

  /* ------------------------------------------------------- ?demo entry path */
  const qs = new URLSearchParams(location.search);
  const demo = qs.has('demo') ? qs.get('demo') : (window.ORBITGUARD_DEMO != null ? String(window.ORBITGUARD_DEMO) : null);
  if (demo != null) {
    const v = demo;
    (async () => {
      dom.viewport.scrollIntoView({ behavior: 'instant', block: 'start' });
      if (v === 'explore') { setMode('explore'); await boot(); await runScreening(); if (S.sel) { jumpTo(S.sel.tcaMs - 5 * 60000); setSpeed(10); flyTo(true, 1.0); } }
      else { await boot(); const n = parseInt(v, 10); if (n >= 2) await goStep(Math.min(6, n) - 1); }
    })();
  }
}
