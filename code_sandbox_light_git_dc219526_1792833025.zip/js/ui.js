/* Page-level UI: scroll reveal + counters */
(function () {
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.15 });
  document.querySelectorAll('.card, .flow-node, .sol-list li, .stack-col').forEach((el, i) => {
    el.classList.add('reveal');
    el.style.transitionDelay = (i % 6) * 70 + 'ms';
    io.observe(el);
  });

  document.querySelectorAll('[data-count]').forEach((el) => {
    const end = +el.dataset.count;
    const t0 = performance.now();
    const fmt = (v) => v >= 1e6 ? (v / 1e6).toFixed(1).replace('.0', '') + 'M+' : Math.round(v).toLocaleString() + (v >= end ? '+' : '');
    (function tick(t) {
      const k = Math.min(1, (t - t0) / 1800);
      el.textContent = fmt(end * (1 - Math.pow(1 - k, 3)));
      if (k < 1) requestAnimationFrame(tick);
    })(t0);
  });
})();
