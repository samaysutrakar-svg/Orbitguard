/* Hero: cinematic Earth wrapped in a GPU-animated debris cloud */
import * as THREE from 'three';
import { createEarth, createStars, sunDirection } from './globe.js';

const canvas = document.getElementById('hero-canvas');
if (canvas) init();

function init() {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(38, 1, 0.01, 200);
  camera.position.set(0.6, 0.9, 4.1);
  camera.lookAt(0.55, 0, 0);

  const world = new THREE.Group();
  world.position.x = 0.95;
  world.rotation.z = 0.32;
  scene.add(world);
  const earth = createEarth({ segments: 80 });
  world.add(earth.root);
  scene.add(createStars(3000));

  // ---- debris cloud: orbit elements in attributes, Kepler motion on the GPU
  const N = 9000;
  const g = new THREE.BufferGeometry();
  const a = new Float32Array(N * 4), b = new Float32Array(N * 3), pos = new Float32Array(N * 3);
  const shells = [ // altitude km, inclination deg, weight, color mode
    [550, 53, 0.22, 0], [780, 98.5, 0.22, 1], [850, 74, 0.14, 1], [1200, 87, 0.08, 0],
    [420, 51.6, 0.07, 0], [20200, 55, 0.06, 2], [35786, 0.1, 0.07, 2], [300 + Math.random(), 30, 0.14, 1]
  ];
  for (let i = 0; i < N; i++) {
    let r = Math.random(), s = shells[0];
    for (const sh of shells) { if ((r -= sh[2]) <= 0) { s = sh; break; } }
    const alt = s[0] < 2000 ? s[0] + (Math.random() - 0.5) * 380 : s[0] * (1 + (Math.random() - 0.5) * 0.04);
    const R = 1 + alt / 6378.137;
    const inc = (s[1] + (Math.random() - 0.5) * 6) * Math.PI / 180;
    const raan = Math.random() * Math.PI * 2;
    const n = Math.sqrt(1 / (R * R * R)) * 0.9;           // relative mean motion
    a.set([R, inc, raan, n], i * 4);
    b.set([Math.random() * Math.PI * 2, s[3], Math.random()], i * 3);
  }
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('aOrb', new THREE.BufferAttribute(a, 4));
  g.setAttribute('aPh', new THREE.BufferAttribute(b, 3));
  const mat = new THREE.ShaderMaterial({
    uniforms: { uT: { value: 0 }, uPR: { value: renderer.getPixelRatio() } },
    vertexShader: /* glsl */`
      attribute vec4 aOrb; attribute vec3 aPh; uniform float uT; uniform float uPR;
      varying vec3 vC; varying float vA;
      void main(){
        float R = aOrb.x, inc = aOrb.y, raan = aOrb.z, n = aOrb.w;
        float u = aPh.x + uT * n;
        vec3 p = vec3(cos(u), 0.0, sin(u)) * R;
        p = vec3(p.x, -p.z * sin(inc), p.z * cos(inc));
        float cr = cos(raan), sr = sin(raan);
        p = vec3(p.x * cr - p.z * sr, p.y, p.x * sr + p.z * cr);
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_Position = projectionMatrix * mv;
        gl_PointSize = (1.2 + aPh.z * 1.8) * uPR * (3.5 / -mv.z);
        vC = aPh.y < 0.5 ? vec3(0.35, 0.85, 1.0) : (aPh.y < 1.5 ? vec3(1.0, 0.55, 0.25) : vec3(0.75, 0.6, 1.0));
        vA = 0.55 + aPh.z * 0.45;
      }`,
    fragmentShader: /* glsl */`
      varying vec3 vC; varying float vA;
      void main(){ float d = length(gl_PointCoord - 0.5); if (d > 0.5) discard; gl_FragColor = vec4(vC, vA * smoothstep(0.5, 0.05, d)); }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending
  });
  const cloud = new THREE.Points(g, mat);
  world.add(cloud);

  // ---- a highlighted "guarded" satellite with orbit ring
  const ringR = 1 + 600 / 6378;
  const ring = new THREE.Mesh(new THREE.TorusGeometry(ringR, 0.0022, 6, 256), new THREE.MeshBasicMaterial({ color: 0x38e1ff, transparent: true, opacity: 0.85 }));
  const ringPivot = new THREE.Group(); ringPivot.rotation.x = Math.PI / 2 - 0.9; ringPivot.add(ring); world.add(ringPivot);
  const sat = new THREE.Mesh(new THREE.SphereGeometry(0.018, 16, 16), new THREE.MeshBasicMaterial({ color: 0xffffff }));
  const halo = new THREE.Mesh(new THREE.SphereGeometry(0.06, 24, 24), new THREE.MeshBasicMaterial({ color: 0x38e1ff, transparent: true, opacity: 0.18, depthWrite: false }));
  sat.add(halo); ringPivot.add(sat);

  function resize() {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    world.position.x = w < 800 ? 0 : 0.95;
    camera.position.set(w < 800 ? 0 : 0.6, w < 800 ? 0.4 : 0.9, w < 800 ? 5.4 : 4.1);
    camera.lookAt(w < 800 ? 0 : 0.55, w < 800 ? -0.6 : 0, 0);
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize); resize();

  let mx = 0, my = 0;
  window.addEventListener('pointermove', (e) => { mx = e.clientX / innerWidth - 0.5; my = e.clientY / innerHeight - 0.5; });

  let visible = true;
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; }).observe(canvas);

  const clock = new THREE.Clock();
  const sun = sunDirection(Date.now());
  earth.setSun(sun);
  (function loop() {
    requestAnimationFrame(loop);
    if (!visible) return;
    const t = clock.getElapsedTime();
    mat.uniforms.uT.value = t * 0.6;
    earth.setRotation(t * 0.05, t * 1000);
    const u = t * 0.55;
    sat.position.set(Math.cos(u) * ringR, Math.sin(u) * ringR, 0);
    halo.scale.setScalar(1 + Math.sin(t * 4) * 0.25);
    world.rotation.y += (mx * 0.4 - world.rotation.y) * 0.02;
    world.rotation.x += (my * 0.2 - world.rotation.x) * 0.02;
    renderer.render(scene, camera);
  })();
}
