/* Shared 3D helpers: Earth with day/night shader, atmosphere, stars, frame conversion */
import * as THREE from 'three';

export const RE = 6378.137;

/* ECI (km, z = north) -> scene units (Earth radius = 1, y = up) */
export function eciToScene(p, out = new THREE.Vector3()) {
  return out.set(p.x / RE, p.z / RE, -p.y / RE);
}

/* Approximate Sun direction in ECI -> scene coords (low precision almanac) */
export function sunDirection(ms, out = new THREE.Vector3()) {
  const n = ms / 86400000 + 2440587.5 - 2451545.0;
  const d2r = Math.PI / 180;
  const L = (280.46 + 0.9856474 * n) * d2r;
  const g = (357.528 + 0.9856003 * n) * d2r;
  const lam = L + (1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g)) * d2r;
  const eps = (23.439 - 0.0000004 * n) * d2r;
  const x = Math.cos(lam), y = Math.cos(eps) * Math.sin(lam), z = Math.sin(eps) * Math.sin(lam);
  return out.set(x, z, -y).normalize();
}

const earthVS = /* glsl */`
varying vec2 vUv; varying vec3 vN; varying vec3 vP;
void main(){
  vUv = uv;
  vN = normalize(mat3(modelMatrix) * normal);
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vP = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
const earthFS = /* glsl */`
uniform sampler2D dayMap; uniform sampler2D nightMap; uniform sampler2D specMap;
uniform vec3 sunDir; uniform float nightBoost;
varying vec2 vUv; varying vec3 vN; varying vec3 vP;
void main(){
  vec3 n = normalize(vN);
  float d = dot(n, sunDir);
  float m = smoothstep(-0.18, 0.22, d);
  vec3 day = texture2D(dayMap, vUv).rgb;
  vec3 night = texture2D(nightMap, vUv).rgb * vec3(1.0, 0.78, 0.5) * nightBoost;
  vec3 v = normalize(cameraPosition - vP);
  vec3 h = normalize(sunDir + v);
  float spec = pow(max(dot(n, h), 0.0), 38.0) * texture2D(specMap, vUv).r * 0.55;
  vec3 col = mix(night + day * 0.05, day * (0.2 + 1.0 * max(d, 0.0)) + vec3(1.0,0.95,0.85) * spec, m);
  float fres = pow(1.0 - max(dot(n, v), 0.0), 3.0);
  col += vec3(0.25, 0.55, 1.0) * fres * (0.25 + 0.6 * m);
  gl_FragColor = vec4(col, 1.0);
}`;

const atmoVS = /* glsl */`
varying vec3 vN; varying vec3 vW;
void main(){ vN = normalize(mat3(modelMatrix) * normal); vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`;
const atmoFS = /* glsl */`
uniform vec3 color; uniform vec3 sunDir; varying vec3 vN; varying vec3 vW;
void main(){
  vec3 v = normalize(cameraPosition - vW);
  float rim = 1.0 - abs(dot(normalize(vN), v));
  float i = pow(rim, 2.2) * 1.15;
  float lit = 0.35 + 0.65 * smoothstep(-0.4, 0.4, dot(normalize(vW), sunDir));
  gl_FragColor = vec4(color * i * lit, i * lit);
}`;

export function createEarth({ base = 'images/', segments = 96, clouds = true } = {}) {
  const loader = new THREE.TextureLoader();
  const load = (f) => { const t = loader.load(base + f); t.anisotropy = 8; return t; };
  const root = new THREE.Group();        // inertial (ECI) frame
  const spin = new THREE.Group();        // rotates with GMST
  root.add(spin);

  const uniforms = {
    dayMap: { value: load('earth_day.jpg') },
    nightMap: { value: load('earth_lights.png') },
    specMap: { value: load('earth_specular.jpg') },
    sunDir: { value: new THREE.Vector3(1, 0, 0) },
    nightBoost: { value: 1.7 }
  };
  const earth = new THREE.Mesh(
    new THREE.SphereGeometry(1, segments, segments),
    new THREE.ShaderMaterial({ uniforms, vertexShader: earthVS, fragmentShader: earthFS })
  );
  spin.add(earth);

  let cloudMesh = null;
  if (clouds) {
    const ct = load('earth_clouds.png');
    // Works for both "white + alpha" and "greyscale, no alpha" cloud maps
    cloudMesh = new THREE.Mesh(
      new THREE.SphereGeometry(1.006, 64, 64),
      new THREE.ShaderMaterial({
        uniforms: { map: { value: ct }, sunDir: uniforms.sunDir },
        vertexShader: /* glsl */`
          varying vec2 vUv; varying vec3 vN;
          void main(){ vUv = uv; vN = normalize(mat3(modelMatrix) * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: /* glsl */`
          uniform sampler2D map; uniform vec3 sunDir; varying vec2 vUv; varying vec3 vN;
          void main(){
            vec4 t = texture2D(map, vUv);
            float a = t.a * max(max(t.r, t.g), t.b);
            float l = 0.06 + 0.94 * smoothstep(-0.15, 0.35, dot(normalize(vN), sunDir));
            gl_FragColor = vec4(vec3(l), a * 0.6 * (0.2 + 0.8 * l));
          }`,
        transparent: true, depthWrite: false
      })
    );
    spin.add(cloudMesh);
  }

  const atmoU = { color: { value: new THREE.Color(0x4fb4ff) }, sunDir: uniforms.sunDir };
  const atmo = new THREE.Mesh(
    new THREE.SphereGeometry(1.045, 64, 64),
    new THREE.ShaderMaterial({ uniforms: atmoU, vertexShader: atmoVS, fragmentShader: atmoFS, transparent: true, blending: THREE.AdditiveBlending, side: THREE.BackSide, depthWrite: false })
  );
  root.add(atmo);

  const sunLight = new THREE.DirectionalLight(0xffffff, 1.6);
  const amb = new THREE.AmbientLight(0x334466, 0.5);
  root.add(sunLight, amb);

  return {
    root, spin, earth, clouds: cloudMesh, uniforms,
    setSun(dir) { uniforms.sunDir.value.copy(dir); sunLight.position.copy(dir).multiplyScalar(10); },
    setRotation(gmstRad, t = 0) { spin.rotation.y = gmstRad; if (cloudMesh) cloudMesh.rotation.y = t * 0.00002; }
  };
}

export function createStars(count = 4000, radius = 90) {
  const g = new THREE.BufferGeometry();
  const pos = new Float32Array(count * 3), col = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, r = radius * (0.8 + Math.random() * 0.2);
    const s = Math.sqrt(1 - u * u);
    pos.set([r * s * Math.cos(th), r * u, r * s * Math.sin(th)], i * 3);
    const t = Math.random();
    const c = t < 0.15 ? [1, 0.85, 0.7] : t < 0.3 ? [0.7, 0.8, 1] : [1, 1, 1];
    const b = 0.4 + Math.random() * 0.6;
    col.set([c[0] * b, c[1] * b, c[2] * b], i * 3);
  }
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return new THREE.Points(g, new THREE.PointsMaterial({ size: 1.4, sizeAttenuation: false, vertexColors: true, transparent: true, opacity: 0.9, depthWrite: false }));
}

/* Round glowing sprite texture */
export function glowTexture(inner = 'rgba(255,255,255,1)', outer = 'rgba(255,255,255,0)') {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const x = c.getContext('2d');
  const g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, inner); g.addColorStop(0.25, inner.replace(/[\d.]+\)$/, '0.6)')); g.addColorStop(1, outer);
  x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c);
  return t;
}

/* Point cloud material with per-point color, size and alpha */
export function pointsMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: { uPR: { value: Math.min(window.devicePixelRatio, 2) }, uScale: { value: 1.0 } },
    vertexShader: /* glsl */`
      attribute vec3 aColor; attribute float aSize; attribute float aAlpha;
      uniform float uPR; uniform float uScale;
      varying vec3 vC; varying float vA;
      void main(){
        vC = aColor; vA = aAlpha;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        float s = aSize * uPR * uScale * (3.0 / max(-mv.z, 0.05));
        gl_PointSize = clamp(s, 1.6 * uPR, 18.0 * uPR) * step(0.001, aAlpha);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */`
      varying vec3 vC; varying float vA;
      void main(){
        vec2 c = gl_PointCoord - 0.5; float d = length(c);
        if (d > 0.5) discard;
        float core = smoothstep(0.5, 0.0, d);
        gl_FragColor = vec4(vC * (0.55 + core * 0.9), vA * core);
      }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending
  });
}
