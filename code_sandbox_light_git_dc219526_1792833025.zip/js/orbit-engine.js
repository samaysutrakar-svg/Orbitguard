/* ==========================================================================
   OrbitGuard Orbit Engine
   - Ingests real orbital data from the CelesTrak GP API (TLE format)
   - Decodes TLEs and propagates with SGP4 (satellite.js = Vallado SGP4, same
     algorithm as the Python `sgp4` package used in the original OrbitGuard)
   - Two-stage conjunction screening (apogee/perigee filter + time-stepped
     distance search with golden-section TCA refinement)
   - Risk scoring (miss distance, RIC frame, relative velocity, Pc estimate)
   - Mitigation planning (along-track phasing Δv)
   Exposed as window.OrbitEngine
   ========================================================================== */
(function (global) {
  'use strict';

  const RE = 6378.137;          // km, WGS-72/84 equatorial radius
  const MU = 398600.4418;       // km^3/s^2
  const DAY_MS = 86400000;
  const API_BASE = 'https://celestrak.org/NORAD/elements/gp.php';
  const CACHE_MS = 2 * 3600 * 1000; // CelesTrak asks clients not to re-download within 2h

  const GROUPS = {
    'fengyun-1c-debris': { label: 'FENGYUN 1C debris · 2007 ASAT test', short: 'FY-1C debris', synth: { alt: [700, 1050], inc: [98.3, 99.4], n: 900 } },
    'cosmos-2251-debris': { label: 'COSMOS 2251 debris · 2009 collision', short: 'COSMOS 2251 debris', synth: { alt: [620, 900], inc: [73.7, 74.3], n: 600 } },
    'iridium-33-debris': { label: 'IRIDIUM 33 debris · 2009 collision', short: 'IRIDIUM 33 debris', synth: { alt: [690, 860], inc: [86.1, 86.7], n: 300 } },
    'stations': { label: 'Space stations', short: 'Stations' },
    'visual': { label: '100 brightest satellites', short: 'Brightest' },
    'weather': { label: 'Weather satellites', short: 'Weather' }
  };

  const SYNTH_FIXED = {
    stations: [
      ['ISS (ZARYA)', 25544, 418, 51.64], ['CSS (TIANHE)', 48274, 385, 41.47],
      ['CSS (WENTIAN)', 53239, 385, 41.47], ['ISS (NAUKA)', 49044, 418, 51.64]
    ],
    visual: [
      ['HST', 20580, 515, 28.47], ['SL-16 R/B', 22566, 840, 71.0], ['ENVISAT', 27386, 765, 98.2],
      ['SL-8 R/B', 11574, 760, 74.0], ['TERRA', 25994, 705, 98.2], ['AQUA', 27424, 705, 98.2]
    ],
    weather: [
      ['NOAA 15', 25338, 808, 98.55], ['NOAA 18', 28654, 852, 98.95], ['NOAA 19', 33591, 852, 99.15],
      ['METOP-B', 38771, 817, 98.70], ['METOP-C', 43689, 817, 98.70], ['FENGYUN 3D', 43010, 830, 98.75],
      ['METEOR-M 2', 40069, 820, 98.60]
    ]
  };

  /* ---------------------------------------------------------------- utils */
  const sub = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
  const add = (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z });
  const scale = (a, s) => ({ x: a.x * s, y: a.y * s, z: a.z * s });
  const dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  const cross = (a, b) => ({ x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x });
  const norm = (a) => Math.sqrt(dot(a, a));
  const unit = (a) => { const n = norm(a) || 1; return scale(a, 1 / n); };
  const vec = { sub, add, scale, dot, cross, norm, unit };

  function checksum(line) {
    let s = 0;
    for (let i = 0; i < 68; i++) {
      const c = line[i];
      if (c >= '0' && c <= '9') s += +c;
      else if (c === '-') s += 1;
    }
    return s % 10;
  }

  /* ------------------------------------------------------- TLE handling */
  function parseTLE(text) {
    const lines = text.split(/\r?\n/).map(l => l.trimEnd()).filter(l => l.trim().length);
    const out = [];
    for (let i = 0; i < lines.length - 1; i++) {
      const l1 = lines[i], l2 = lines[i + 1];
      if (l1.startsWith('1 ') && l2.startsWith('2 ')) {
        const prev = i > 0 ? lines[i - 1] : '';
        const name = prev && !prev.startsWith('1 ') && !prev.startsWith('2 ') ? prev.trim() : 'NORAD ' + l1.substring(2, 7).trim();
        const rec = buildRecord(name, l1, l2);
        if (rec) out.push(rec);
        i++;
      }
    }
    return out;
  }

  function buildRecord(name, l1, l2) {
    let satrec;
    try { satrec = global.satellite.twoline2satrec(l1, l2); } catch (e) { return null; }
    if (!satrec || satrec.error) return null;
    const nRadS = satrec.no / 60;                    // rad/min -> rad/s
    const a = Math.cbrt(MU / (nRadS * nRadS));
    const e = satrec.ecco;
    const epochMs = (satrec.jdsatepoch - 2440587.5) * DAY_MS;
    return {
      name, id: parseInt(l1.substring(2, 7), 10), intl: l1.substring(9, 17).trim(), l1, l2, satrec,
      incl: satrec.inclo * 180 / Math.PI,
      raan: satrec.nodeo * 180 / Math.PI,
      ecc: e,
      argp: satrec.argpo * 180 / Math.PI,
      ma: satrec.mo * 180 / Math.PI,
      revDay: satrec.no * 1440 / (2 * Math.PI),
      a, perigee: a * (1 - e) - RE, apogee: a * (1 + e) - RE,
      periodMin: 2 * Math.PI / satrec.no,
      bstar: satrec.bstar,
      epochMs
    };
  }

  function makeTLE(id, name, inclDeg, raanDeg, ecc, argpDeg, maDeg, revDay, epoch) {
    const d = new Date(epoch);
    const yy = String(d.getUTCFullYear() % 100).padStart(2, '0');
    const doy = (epoch - Date.UTC(d.getUTCFullYear(), 0, 1)) / DAY_MS + 1;
    const ids = String(id % 100000).padStart(5, '0');
    const n360 = (x) => ((x % 360) + 360) % 360;
    let l1 = '1 ' + ids + 'U ' + '26001A  ' + ' ' + yy + doy.toFixed(8).padStart(12, '0') +
      ' ' + ' .00000000' + ' ' + ' 00000-0' + ' ' + ' 00000-0' + ' 0 ' + ' 999';
    let l2 = '2 ' + ids + ' ' + inclDeg.toFixed(4).padStart(8) + ' ' + n360(raanDeg).toFixed(4).padStart(8) + ' ' +
      Math.round(Math.min(ecc, 0.9999999) * 1e7).toString().padStart(7, '0') + ' ' +
      n360(argpDeg).toFixed(4).padStart(8) + ' ' + n360(maDeg).toFixed(4).padStart(8) + ' ' +
      revDay.toFixed(8).padStart(11) + '00001';
    l1 += checksum(l1); l2 += checksum(l2);
    return buildRecord(name, l1, l2);
  }

  const revDayFromAlt = (altKm) => Math.sqrt(MU / Math.pow(RE + altKm, 3)) * 86400 / (2 * Math.PI);

  /* Classical orbital elements from an ECI state vector (two-body) */
  function rv2coe(r, v) {
    const rm = norm(r), vm = norm(v);
    const h = cross(r, v), hm = norm(h);
    const n = { x: -h.y, y: h.x, z: 0 }, nm = norm(n);
    const ev = scale(sub(scale(r, vm * vm - MU / rm), scale(v, dot(r, v))), 1 / MU);
    const e = Math.max(norm(ev), 1e-9);
    const energy = vm * vm / 2 - MU / rm;
    const a = -MU / (2 * energy);
    const inc = Math.acos(h.z / hm);
    let raan = Math.acos(Math.max(-1, Math.min(1, n.x / nm))); if (n.y < 0) raan = 2 * Math.PI - raan;
    let argp = Math.acos(Math.max(-1, Math.min(1, dot(n, ev) / (nm * e)))); if (ev.z < 0) argp = 2 * Math.PI - argp;
    let nu = Math.acos(Math.max(-1, Math.min(1, dot(ev, r) / (e * rm)))); if (dot(r, v) < 0) nu = 2 * Math.PI - nu;
    const E = 2 * Math.atan(Math.sqrt((1 - e) / (1 + e)) * Math.tan(nu / 2));
    const M = E - e * Math.sin(E);
    const D = 180 / Math.PI;
    return { a, e, inc: inc * D, raan: raan * D, argp: argp * D, ma: M * D, revDay: Math.sqrt(MU / (a * a * a)) * 86400 / (2 * Math.PI) };
  }

  /* -------------------------------------------------------- propagation */
  function posVelAt(o, ms) {
    const jd = ms / DAY_MS + 2440587.5;
    const tsince = (jd - o.satrec.jdsatepoch) * 1440;
    let pv;
    try { pv = global.satellite.sgp4(o.satrec, tsince); } catch (e) { return null; }
    if (!pv || !pv.position || typeof pv.position !== 'object' || isNaN(pv.position.x)) return null;
    return pv;
  }
  function posAt(o, ms) { const pv = posVelAt(o, ms); return pv ? pv.position : null; }
  function gmst(ms) { return global.satellite.gstime(new Date(ms)); }
  function geodetic(p, ms) {
    const g = global.satellite.eciToGeodetic(p, gmst(ms));
    return { lat: g.latitude * 180 / Math.PI, lon: g.longitude * 180 / Math.PI, alt: g.height };
  }

  /* ------------------------------------------------------------ fetching */
  async function fetchGroup(group, opts = {}) {
    const url = `${API_BASE}?GROUP=${encodeURIComponent(group)}&FORMAT=tle`;
    const key = 'orbitguard:' + group;
    if (!opts.force) {
      try {
        const c = JSON.parse(localStorage.getItem(key) || 'null');
        if (c && Date.now() - c.t < CACHE_MS && c.text) {
          const objects = parseTLE(c.text);
          if (objects.length) return { group, url, objects, source: 'cache', status: 200, ms: 0, bytes: c.text.length, fetchedAt: c.t };
        }
      } catch (e) { /* ignore */ }
    }
    const t0 = performance.now();
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), opts.timeout || 12000);
    let res;
    try { res = await fetch(url, { signal: ctrl.signal }); }
    finally { clearTimeout(timer); }
    const text = await res.text();
    const ms = Math.round(performance.now() - t0);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const objects = parseTLE(text);
    if (!objects.length) throw new Error('Empty / rate-limited response');
    try { localStorage.setItem(key, JSON.stringify({ t: Date.now(), text })); } catch (e) { /* quota */ }
    return { group, url, objects, source: 'live', status: res.status, ms, bytes: text.length, fetchedAt: Date.now() };
  }

  /* Deterministic synthetic catalog — used only when the API is unreachable */
  function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
  function syntheticGroup(group) {
    const url = `${API_BASE}?GROUP=${group}&FORMAT=tle`;
    const now = Date.now();
    const out = [];
    if (SYNTH_FIXED[group]) {
      const r = rng(group.length * 97);
      SYNTH_FIXED[group].forEach(([name, id, alt, inc]) => {
        const rec = makeTLE(id, name, inc, r() * 360, 0.0004 + r() * 0.0008, r() * 360, r() * 360, revDayFromAlt(alt), now);
        if (rec) out.push(rec);
      });
    } else {
      const cfg = GROUPS[group].synth;
      const r = rng(group.length * 7919);
      for (let i = 0; i < cfg.n; i++) {
        const perigee = cfg.alt[0] + r() * (cfg.alt[1] - cfg.alt[0]) * 0.8;
        const apogee = perigee + r() * (cfg.alt[1] - perigee);
        const a = RE + (perigee + apogee) / 2;
        const e = (apogee - perigee) / (2 * a);
        const inc = cfg.inc[0] + r() * (cfg.inc[1] - cfg.inc[0]);
        const rec = makeTLE(90000 + i, `${GROUPS[group].short.replace(' debris', '')} DEB`, inc, r() * 360, e, r() * 360, r() * 360, revDayFromAlt(a - RE), now);
        if (rec) out.push(rec);
      }
    }
    return { group, url, objects: out, source: 'simulated', status: 0, ms: 0, bytes: 0, fetchedAt: now };
  }

  /* Fit an SGP4 mean-element TLE that reproduces state (r,v) at epoch ms.
     Osculating -> mean conversion via iterative differential correction. */
  function fitTLE(id, name, r, v, ms) {
    let rr = r, vv = v, rec = null;
    for (let it = 0; it < 6; it++) {
      const coe = rv2coe(rr, vv);
      rec = makeTLE(id, name, coe.inc, coe.raan, Math.max(coe.e, 0.00001), coe.argp, coe.ma, coe.revDay, ms);
      if (!rec) return null;
      const pv = posVelAt(rec, ms); if (!pv) return rec;
      const dr = sub(r, pv.position), dv = sub(v, pv.velocity);
      if (norm(dr) < 0.01) break;
      rr = add(rr, dr); vv = add(vv, dv);
    }
    return rec;
  }

  /* Create test debris whose orbit crosses the target's path (clearly labelled as synthetic) */
  function injectThreats(target, objects, startMs, hours = 6) {
    const offsets = [[0.36, 0.35, 24], [0.6, 2.4, 62], [0.85, 6.5, 145]]; // fraction of window, km offset, plane rotation deg
    offsets.forEach(([f, offKm, rot], k) => {
      const tca = startMs + f * hours * 3600000;
      const pv = posVelAt(target, tca); if (!pv) return;
      const r = pv.position, v = pv.velocity;
      const ru = unit(r);
      const th = rot * Math.PI / 180;
      // rotate velocity around the local radial axis (Rodrigues) -> crossing orbit plane
      const vr = add(add(scale(v, Math.cos(th)), scale(cross(ru, v), Math.sin(th))), scale(ru, dot(ru, v) * (1 - Math.cos(th))));
      const off = unit(add(ru, scale(unit(cross(r, v)), 0.6)));
      const rec = fitTLE(99901 + k, 'TEST DEBRIS ' + String.fromCharCode(65 + k) + ' (SYNTHETIC)', add(r, scale(off, offKm)), vr, tca);
      if (rec) { rec.synthetic = true; objects.push(rec); }
    });
  }

  /* ----------------------------------------------------------- screening */
  function estimatePc(missKm, hbrKm = 0.05, sigmaKm = 1.0) {
    // Isotropic 2-D Gaussian, small hard-body approximation (Foster/Chan style)
    return Math.min(1, (hbrKm * hbrKm) / (2 * sigmaKm * sigmaKm) * Math.exp(-(missKm * missKm) / (2 * sigmaKm * sigmaKm)));
  }
  function riskLevel(missKm, pc, thresholdKm) {
    if (pc >= 1e-4) return { key: 'high', label: 'HIGH', color: '#ff4d5e' };
    if (pc >= 1e-6) return { key: 'med', label: 'MEDIUM', color: '#ffb020' };
    if (missKm <= thresholdKm) return { key: 'low', label: 'LOW', color: '#ffe066' };
    return { key: 'watch', label: 'WATCH', color: '#38e1ff' };
  }

  function coarseFilter(target, objects, thresholdKm) {
    const pad = thresholdKm + 15;
    const lo = target.perigee - pad, hi = target.apogee + pad;
    const candidates = [], rejected = [];
    for (const o of objects) {
      if (o.id === target.id) continue;
      if (o.apogee < lo || o.perigee > hi) rejected.push(o); else candidates.push(o);
    }
    return { lo, hi, pad, candidates, rejected };
  }

  function refine(target, o, msA, msB) {
    const f = (ms) => { const a = posAt(target, ms), b = posAt(o, ms); return a && b ? norm(sub(a, b)) : Infinity; };
    const g = 0.6180339887;
    let a = msA, b = msB, c = b - g * (b - a), d = a + g * (b - a), fc = f(c), fd = f(d);
    for (let i = 0; i < 40 && b - a > 5; i++) {
      if (fc < fd) { b = d; d = c; fd = fc; c = b - g * (b - a); fc = f(c); }
      else { a = c; c = d; fc = fd; d = a + g * (b - a); fd = f(d); }
    }
    const ms = (a + b) / 2;
    return { ms, d: f(ms) };
  }

  function assess(target, o, tcaMs, thresholdKm) {
    const p1 = posVelAt(target, tcaMs), p2 = posVelAt(o, tcaMs);
    if (!p1 || !p2) return null;
    const rel = sub(p2.position, p1.position);
    const relV = sub(p2.velocity, p1.velocity);
    const R = unit(p1.position), C = unit(cross(p1.position, p1.velocity)), I = cross(C, R);
    const miss = norm(rel);
    const pc = estimatePc(miss);
    return {
      obj: o, tcaMs, miss, relVel: norm(relV),
      ric: { r: dot(rel, R), i: dot(rel, I), c: dot(rel, C) },
      pc, risk: riskLevel(miss, pc, thresholdKm),
      rel, relV, t: p1, d: p2
    };
  }

  async function screen(target, objects, opts) {
    const { startMs, hours = 6, stepSec = 60, thresholdKm = 25, onProgress, keep = 30 } = opts;
    const t0 = performance.now();
    const cf = coarseFilter(target, objects, thresholdKm);
    const n = Math.floor(hours * 3600 / stepSec) + 1;
    const stepMs = stepSec * 1000;
    const tp = new Array(n);
    for (let k = 0; k < n; k++) tp[k] = posAt(target, startMs + k * stepMs);
    const slack = 7.6 * stepSec; // half-step travel at ~15 km/s relative
    const found = [];
    let evals = n;
    for (let ci = 0; ci < cf.candidates.length; ci++) {
      const o = cf.candidates[ci];
      let best = null, p2 = Infinity, p1 = Infinity, gMin = Infinity, gK = -1;
      for (let k = 0; k < n; k++) {
        const a = tp[k]; const b = posAt(o, startMs + k * stepMs); evals++;
        let d = Infinity;
        if (a && b) { const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z; d = Math.sqrt(dx * dx + dy * dy + dz * dz); }
        const isLast = k === n - 1;
        if (k >= 1 && p1 <= p2 && p1 <= d && p1 < thresholdKm + slack) {
          const r = refine(target, o, startMs + Math.max(0, k - 2) * stepMs, startMs + k * stepMs); evals += 80;
          if (!best || r.d < best.d) best = r;
        }
        if (isLast && d < p1 && d < thresholdKm + slack) {
          const r = refine(target, o, startMs + (k - 1) * stepMs, startMs + k * stepMs); evals += 80;
          if (!best || r.d < best.d) best = r;
        }
        if (d < gMin) { gMin = d; gK = k; }
        p2 = p1; p1 = d;
      }
      // always refine the global sampled minimum so we can list the closest approaches
      if (gK >= 0) {
        const r = refine(target, o, startMs + Math.max(0, gK - 1) * stepMs, startMs + Math.min(n - 1, gK + 1) * stepMs); evals += 80;
        if (!best || r.d < best.d) best = r;
      }
      if (best && isFinite(best.d)) found.push({ o, ms: best.ms, d: best.d });
      if (ci % 20 === 0) {
        onProgress && onProgress(ci / cf.candidates.length, ci, cf.candidates.length);
        await new Promise(r => setTimeout(r, 0));
      }
    }
    onProgress && onProgress(1, cf.candidates.length, cf.candidates.length);
    found.sort((a, b) => a.d - b.d);
    // Docked modules / visiting vehicles / formation flyers share the asset's orbit
    // (relative speed ~0): they are not collision threats and cannot be manoeuvred away from.
    const coorbital = [];
    const conjunctions = [];
    for (const f of found) {
      if (conjunctions.length >= keep) break;
      const c = assess(target, f.o, f.ms, thresholdKm);
      if (!c) continue;
      if (c.relVel < 0.05) { coorbital.push(c); continue; }
      conjunctions.push(c);
    }
    return {
      target, startMs, hours, stepSec, thresholdKm, coarse: cf, conjunctions, coorbital,
      flagged: conjunctions.filter(c => c.miss <= thresholdKm).length,
      evals, elapsedMs: Math.round(performance.now() - t0)
    };
  }

  function distanceSeries(target, o, startMs, endMs, samples = 360) {
    const out = [];
    for (let i = 0; i <= samples; i++) {
      const ms = startMs + (endMs - startMs) * i / samples;
      const a = posAt(target, ms), b = posAt(o, ms);
      out.push({ ms, d: a && b ? norm(sub(a, b)) : null });
    }
    return out;
  }

  /* ----------------------------------------------------------- mitigation */
  function planManeuver(target, conj, safeKm, earliestMs, massKg = 1500) {
    const T = target.periodMin * 60; // s
    const burnMs = Math.max(earliestMs, conj.tcaMs - 1.5 * T * 1000);
    const leadS = Math.max(60, (conj.tcaMs - burnMs) / 1000);
    const vhat = unit(conj.t.velocity);
    // Encounter (B-plane) geometry: closest distance is measured perpendicular to relative velocity.
    // Shifting the target along-track by s changes the miss vector to P(rel - s·v̂).
    const w = unit(conj.relV);
    const P = (a) => sub(a, scale(w, dot(a, w)));
    const m0 = P(conj.rel), u = P(vhat);
    const goal = safeKm * 1.15; // margin for linearisation error
    let shiftKm = 0;
    if (norm(m0) < goal) {
      const A = dot(u, u), B = -2 * dot(m0, u), C = dot(m0, m0) - goal * goal;
      const disc = Math.max(0, B * B - 4 * A * C);
      const s1 = (-B + Math.sqrt(disc)) / (2 * A), s2 = (-B - Math.sqrt(disc)) / (2 * A);
      shiftKm = Math.abs(s1) < Math.abs(s2) ? s1 : s2;
    }
    const need = Math.abs(shiftKm);
    // Clohessy–Wiltshire: a tangential burn Δv produces along-track drift Δx ≈ -3·Δv·t
    const prograde = shiftKm < 0;
    const dv = need * 1000 / (3 * leadS); // m/s
    const newMiss = need ? norm(sub(m0, scale(u, shiftKm))) : conj.miss;
    const isp = 220, g0 = 9.80665; // hydrazine monoprop reference
    const fuelKg = massKg * (1 - Math.exp(-dv / (isp * g0)));
    return { burnMs, leadS, need, dv, prograde, shiftKm, vhat, newMiss, safeKm, fuelKg, required: need > 0 };
  }

  /* Apply an impulsive along-track burn and re-fit a TLE so the new trajectory
     can be verified with SGP4 (not just the linear estimate). */
  function applyManeuver(target, burnMs, dvMs, prograde) {
    const pv = posVelAt(target, burnMs); if (!pv) return null;
    const vhat = unit(pv.velocity);
    const v2 = add(pv.velocity, scale(vhat, (prograde ? 1 : -1) * dvMs / 1000));
    const rec = fitTLE(target.id, target.name + ' (POST-BURN)', pv.position, v2, burnMs);
    if (rec) rec.maneuvered = true;
    return rec;
  }
  function verifyMiss(newTarget, o, tcaMs, windowMin = 20) {
    return refine(newTarget, o, tcaMs - windowMin * 60000, tcaMs + windowMin * 60000);
  }

  global.OrbitEngine = {
    RE, MU, API_BASE, GROUPS, vec,
    parseTLE, makeTLE, fetchGroup, syntheticGroup, injectThreats,
    posAt, posVelAt, gmst, geodetic,
    coarseFilter, screen, assess, distanceSeries, planManeuver, applyManeuver, verifyMiss, fitTLE, estimatePc
  };
})(window);
