# OrbitGuard — Space Debris Detection, Tracking & Mitigation Planning

A one-page website for Team PHANTOM BYTE · Nakshatra. It includes a working 3D prototype that tracks real space debris in the browser.

## Features
- **Hero**: a 3D Earth with day/night lighting, city lights, clouds and an atmosphere, surrounded by about 9,000 debris particles animated on the GPU.
- **Problem / Solution / Pipeline / Features / Stack** sections, with scroll-reveal effects and animated counters.
- **Mission Control 3D Lab** (`#lab`):
  - Loads real TLE data from the **CelesTrak GP API**: Fengyun‑1C, Cosmos‑2251 and Iridium‑33 debris, plus stations, the brightest satellites and weather satellites. The data is cached in localStorage for 2 h. If the API can't be reached, the Lab uses a clearly labelled simulated catalogue instead.
  - Calculates positions with **SGP4** (satellite.js).
  - **Guided walkthrough** in 6 steps, each with its own 3D view:
    1. Ingest the data
    2. SGP4 position and velocity
    3. Altitude-band filter, shown as shells
    4. Time-stepped screening and the time of closest approach (TCA)
    5. Risk scoring: miss distance split into radial / in-track / cross-track (RIC) arrows, plus the probability of collision (Pc)
    6. Avoidance burn (Δv), checked again with SGP4. The post-burn orbit is shown in green.
  - **Free explore**: choose any protected asset, window, threshold, step size and safe distance. Click any object to inspect it. There's also a conjunction list, a range-vs-time chart (Chart.js) and a timeline with play, scrub and speed controls.
  - Optional *synthetic* crossing objects for stress testing. They are always labelled “SYNTHETIC”.
  - Docked or co-orbital objects (relative speed under 50 m/s) are left out of the conjunction list.

## Files
- `index.html`: the page
- `css/style.css`: styles
- `js/orbit-engine.js`: fetching, TLE parsing, SGP4, screening, risk scoring and manoeuvre planning (`window.OrbitEngine`)
- `js/globe.js`: shared Three.js Earth, stars and point shaders
- `js/hero.js`: the hero scene
- `js/lab.js`: the Mission Control Lab (scene, walkthrough, deck, chart and mitigation)
- `js/ui.js`: scroll reveal and counters
- `images/earth_day.jpg`, `earth_lights.png`, `earth_specular.jpg`, `earth_clouds.png`: Earth textures

## Entry paths
- `index.html`: the normal page
- `index.html?demo`: starts the Lab automatically
- `index.html?demo=6`: starts the Lab and runs every step up to step 6, the mitigation step (any number from 1 to 6 works)
- `index.html?demo=explore`: starts the Lab in free-explore mode, runs a screening and jumps to the closest approach
- `window.ORBITGUARD_DEMO = '6'` (set before the modules load) does the same thing as the `?demo` query; it's a testing hook

## Storage
No database. TLE responses are cached only in the browser's localStorage (`orbitguard:<group>`) for 2 hours.

## Status
Done: hero, all content sections, the full Lab (`js/lab.js`) and Earth textures (from the three.js example textures). Tested in the browser with live CelesTrak data, on desktop and mobile.
Not deployed yet. Publishing needs an approved Hosted Deploy. No database or backend is needed.

## Notes / next steps
- The Pc value uses a simple isotropic covariance model, because TLEs have no covariance data. It is for teaching and demonstration only.
- Possible additions: more catalogue groups (e.g. Starlink, which is heavy) and Web Worker screening for large catalogues.
